# README #

This README is a random.

This repository is for iPay wallet Android app also known as eLipa

* Quick summary

eLipa Wallet is a revolution in digital payments for Africa. With eLipa Wallet, one can:
- Top up using Mobile money or Credit/Debit card
- Pay for goods & services from within our merchant network
- Pay for TV subscriptions
- Pay for utility bills
- Buy airtime 
- Invite your friends to use eLipa Wallet and get rewarded when they sign up.
- Invite potential merchants to use eLipa Wallet and get rewarded when they sign up.
- Request for payments from other eLipa wallet users.

* Version
Current version is 2.3.5

https://owino_cliff@bitbucket.org/ipayafrica/ipaywallet.git

Set Up 

Android Studio 2.1.2
Min SDK 14


* Dependencies

 com.android.support:appcompat-v7:23.4.0
 com.android.support:design:23.4.0
 com.android.support:recyclerview-v7:23.4.0
 com.mcxiaoke.volley:library:1.0.19
 com.android.support:cardview-v7:23.4.0
 com.pkmmte.view:circularimageview:1.1
 com.android.support:support-v4:23.4.0
 com.loopj.android:android-async-http:1.4.9
 me.tatarka.support:jobscheduler:0.1.1
 com.google.firebase:firebase-core:9.0.0
 com.google.firebase:firebase-messaging:9.0.0
 com.jakewharton:butterknife:7.0.1
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact