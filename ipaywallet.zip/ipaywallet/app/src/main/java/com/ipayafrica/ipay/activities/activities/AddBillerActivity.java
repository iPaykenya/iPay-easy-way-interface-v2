package com.ipayafrica.ipay.activities.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.FormValidation;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddBillerActivity extends AppCompatActivity {

    public String account_type_final = "";
    public String account_number_final = "";
    public String account_name_final = "";
    public String category_final = "";

    ImageView notification_back, notify_back;

    LinearLayout biller_water, biller_electricity, biller_tv, expended_water, expended_electricity, expended_tv, container_layout, water_nairobi, kplc_post_paid, kplc_pre_paid,
            tvDs, tvGo, tvZuku, tvStarTimes;

    public PopupWindow mPopupWindow;
    private Context mContext;

    static AddBillerActivity instance;
    public static AddBillerActivity getInstace(){
        if(instance == null){
            instance = new AddBillerActivity ();
        }
        return instance;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_biller);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mContext = this;
        instance = this;

        biller_water = findViewById(R.id.biller_water);
        biller_electricity = findViewById(R.id.biller_electricity);
        biller_tv = findViewById(R.id.biller_tv);
        expended_water = findViewById(R.id.expended_water);
        expended_electricity = findViewById(R.id.expended_electricity);
        expended_tv = findViewById(R.id.expended_tv);
        container_layout = findViewById(R.id.container_layout);
        water_nairobi = findViewById(R.id.water_nairobi);
        kplc_post_paid = findViewById(R.id.kplc_post_paid);
        kplc_pre_paid = findViewById(R.id.kplc_pre_paid);
        tvDs = findViewById(R.id.tvDs);
        tvGo = findViewById(R.id.tvGo);
        tvZuku = findViewById(R.id.tvZuku);
        tvStarTimes = findViewById(R.id.tvStarTimes);

        notification_back = (ImageView) findViewById(R.id.notification_back);
        notify_back       = (ImageView) findViewById(R.id.notify_back);

        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        biller_water.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expended_water.setVisibility(View.VISIBLE);
                expended_electricity.setVisibility(View.GONE);
                expended_tv.setVisibility(View.GONE);
            }
        });

        biller_electricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expended_water.setVisibility(View.GONE);
                expended_electricity.setVisibility(View.VISIBLE);
                expended_tv.setVisibility(View.GONE);
            }
        });

        biller_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expended_water.setVisibility(View.GONE);
                expended_electricity.setVisibility(View.GONE);
                expended_tv.setVisibility(View.VISIBLE);
            }
        });

        water_nairobi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topUpPopUp(getString(R.string.biller_nairobi_water));
            }
        });
        kplc_post_paid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topUpPopUp(getString(R.string.biller_kplc_postpaid));
            }
        });
        kplc_pre_paid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topUpPopUp(getString(R.string.biller_kplc_prepaid));
            }
        });
        tvDs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topUpPopUp(getString(R.string.biller_ds_tv));
            }
        });
        tvGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topUpPopUp(getString(R.string.biller_go_tv));
            }
        });
        tvZuku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topUpPopUp(getString(R.string.biller_zuku_tv));
            }
        });
        tvStarTimes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topUpPopUp(getString(R.string.biller_starttimes_tv));
            }
        });
//        tvDs.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                topUpPopUp("kplc_prepaid");
//            }
//        });

    }

    private void topUpPopUp(final String billerName)
    {
        String category = null;

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layout_add_biller_popup,null, false);

        final TextView account_title = customView.findViewById(R.id.account_title);
        account_title.setText("");
        final EditText account_name = customView.findViewById(R.id.account_name);
        final EditText account_number = customView.findViewById(R.id.account_number);
        final Button add_biller = customView.findViewById(R.id.add_biller);

        if (billerName.equals(getString(R.string.biller_nairobi_water))){
            category = getString(R.string.biller_water_title);
            account_title.setText(getString(R.string.biller_nairobi_water_title));
        }
        if (billerName.equals(getString(R.string.biller_kplc_postpaid))){
            category = getString(R.string.biller_electricity_title);
            account_title.setText(getString(R.string.biller_kplc_postpaid_title));
        }
        if (billerName.equals(getString(R.string.biller_kplc_prepaid))){
            category = getString(R.string.biller_electricity_title);
            account_title.setText(getString(R.string.biller_kplc_prepaid_title));
        }
        if (billerName.equals(getString(R.string.biller_ds_tv))){
            category = getString(R.string.biller_tv_title);
            account_title.setText(getString(R.string.biller_ds_tv_title));
        }
        if (billerName.equals(getString(R.string.biller_go_tv))){
            category = getString(R.string.biller_tv_title);
            account_title.setText(getString(R.string.biller_go_tv_title));
        }
        if (billerName.equals(getString(R.string.biller_zuku_tv))){
            category = getString(R.string.biller_tv_title);
            account_title.setText(getString(R.string.biller_zuku_tv_title));
        }
        if (billerName.equals(getString(R.string.biller_starttimes_tv))){
            category = getString(R.string.biller_tv_title);
            account_title.setText(getString(R.string.biller_starttimes_tv_title));
        }

        final String finalCategory = category;

        add_biller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //validate fields
                if (FormValidation.passwordValidation(account_name.getText().toString().trim()) == false) {
                    Toast.makeText(mContext, getString(R.string.biller_toast_title), Toast.LENGTH_SHORT).show();
                    account_name.requestFocus();
                    return;
                }
                if (FormValidation.passwordValidation(account_number.getText().toString().trim()) == false) {
                    Toast.makeText(mContext, getString(R.string.biller_toast_account_number), Toast.LENGTH_SHORT).show();
                    account_number.requestFocus();
                    return;
                }

                account_type_final = billerName;
                account_number_final = account_number.getText().toString().trim();
                account_name_final = account_name.getText().toString().trim();
                category_final = finalCategory;

                mPopupWindow.dismiss();
                Intent i = new Intent(AddBillerActivity.this, QuickLoginActivity.class);
                i.putExtra(getString(R.string.biller_key_add_billers), getString(R.string.biller_add_billers));
                startActivity(i);

            }
        });

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);
        mPopupWindow.showAtLocation(container_layout, Gravity.CENTER,0,0);

    }

    public void addBiller()
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(AddBillerActivity.this);
        mAuthProgressDialog.setMessage(getString(R.string.biller_processing));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(AddBillerActivity.this);

                String token = String.valueOf(prefferences.get(getString(R.string.biller_token)));

                //form hashmap
                Map<String, String> parameters = new HashMap<>();
                parameters.put(getString(R.string.biller_account_type), account_type_final);
                parameters.put(getString(R.string.biller_account_number), account_number_final);
                parameters.put(getString(R.string.biller_account_name), account_name_final);
                parameters.put(getString(R.string.biller_account_category), category_final);

                HashMap<String, String> header = new HashMap<>();
                header.put(getString(R.string.biller_key_authorization), getString(R.string.my_bearer) + token);

                //send data to volley
                String url = getString(R.string.baseUrl) + getString(R.string.biller_accounts);

                VolleyStringRequest volley = new VolleyStringRequest();
                volley.postData(AddBillerActivity.this, parameters, header, url, new VolleyCallBack() {
                    @Override
                    public void onSuccess(String result) {

                        JSONObject oprator = null;
                        try {

                            oprator = new JSONObject(result);

                            String header_status = oprator.getString(getString(R.string.home_header_status_value));

                            if (header_status.toString().trim().equals(getString(R.string.home_header_status_200))) {
                                Toast.makeText(AddBillerActivity.this, getString(R.string.biller_saved), Toast.LENGTH_SHORT).show();
                            }
                        }catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                });

            }
        }.start();

    }

}
