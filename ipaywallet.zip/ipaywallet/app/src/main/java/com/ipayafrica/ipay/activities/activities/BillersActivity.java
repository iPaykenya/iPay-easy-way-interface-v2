package com.ipayafrica.ipay.activities.activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;

import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.Model;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.adapters.BillersAdaptor;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BillersActivity extends AppCompatActivity {

    ImageView notification_back, notify_back;
    CardView error, data_found;
    Button go_to_mywallet, go_to_topup, go_to_withdrawal, retry_get_billers, add_billers, add_biller_now;

    private ArrayList<Model> models;
    private BillersAdaptor mAdapter;
    RecyclerView billingAccountsRecyclerView;

    static BillersActivity instance;
    public static BillersActivity getInstace(){
        if(instance == null){
            instance = new BillersActivity ();
        }
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billers);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        instance = this;

        go_to_mywallet      = (Button) findViewById(R.id.mywallet);
        go_to_topup         = (Button) findViewById(R.id.topup);
        go_to_withdrawal    = (Button) findViewById(R.id.withdrawal);
        retry_get_billers   = (Button) findViewById(R.id.retry_get_billers);
        add_billers   = (Button) findViewById(R.id.add_billers);
        add_biller_now      = (Button) findViewById(R.id.add_biller_now);

        notification_back = (ImageView) findViewById(R.id.notification_back);
        notify_back       = (ImageView) findViewById(R.id.notify_back);


        error       = (CardView) findViewById(R.id.error);
        data_found  = (CardView) findViewById(R.id.data_found);

        billingAccountsRecyclerView = (RecyclerView) findViewById(R.id.billingAccountsRecyclerView);

        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        /** call wallet activity */
        go_to_mywallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BillersActivity.this, MyWalletActivity.class));
                finish();
            }
        });
        go_to_topup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BillersActivity.this, MyWalletActivity.class));
                finish();
            }
        });
        go_to_withdrawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BillersActivity.this, MyWalletActivity.class));
                finish();
            }
        });

        add_biller_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent water = new Intent(BillersActivity.this, AddBillerActivity.class);
                startActivity(water);
            }
        });

        add_billers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent water = new Intent(BillersActivity.this, AddBillerActivity.class);
                startActivity(water);
            }
        });

        retry_get_billers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /** get quick login **/
                Intent i=new Intent(BillersActivity.this, QuickLoginActivity.class);
                i.putExtra(getString(R.string.biller_activity_key), getString(R.string.biller_value_my_billers));
                startActivity(i);
            }
        });

        /*** <----recycler code---- ***/
        billingAccountsRecyclerView.setHasFixedSize(true);

        models = new ArrayList<>();
        mAdapter = new BillersAdaptor(BillersActivity.this, models);

        @SuppressLint("WrongConstant") LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(BillersActivity.this, LinearLayoutManager.VERTICAL, false);


        billingAccountsRecyclerView.setLayoutManager(mLayoutManager);
        billingAccountsRecyclerView.setItemAnimator(new DefaultItemAnimator());
        billingAccountsRecyclerView.setAdapter(mAdapter);

        /*** ----recycler code />---- ***/

        /** get quick login **/
        Intent i=new Intent(BillersActivity.this, QuickLoginActivity.class);
        i.putExtra(getString(R.string.biller_activity_key), getString(R.string.biller_value_my_billers));
        startActivity(i);

    }

    public void onBackPressed() {

        for (Fragment fragment:getSupportFragmentManager().getFragments()) {
            if (fragment != null) {
                getSupportFragmentManager().beginTransaction().remove(fragment).commit();
                return;
            }}
        super.onBackPressed();
        return;
    }

    /** get billers */
    public void getBiller()
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(BillersActivity.this);
        mAuthProgressDialog.setMessage(getString(R.string.biller_loader));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(BillersActivity.this);

                String token    =  String.valueOf(prefferences.get(getString(R.string.biller_key_token)));

                //form hashmap
                Map<String, String> params = new HashMap<String, String>();

                HashMap<String, String> header = new HashMap<String, String>();
                header.put(getString(R.string.biller_key_authorization), getString(R.string.my_bearer) + token);

                //send data to volley
                String url = getString(R.string.baseUrl)+getString(R.string.biller_wallet);

                VolleyStringRequest volley = new VolleyStringRequest();
                volley.getData(BillersActivity.this, params, header, url, new VolleyCallBack() {
                    @Override
                    public void onSuccess(String result) {

                        //process results
                       JSONObject oprator = null;
                        try {

                            oprator = new JSONObject(result);

                            String header_status = oprator.getString(getString(R.string.home_header_status_value));

                            if (header_status.toString().trim().equals(getString(R.string.home_header_status_200))) {

                                error.setVisibility(View.GONE);
                                data_found.setVisibility(View.VISIBLE);

                                JSONArray jsonArray = oprator.getJSONArray(getString(R.string.biller_account));

                                models.clear();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    Model data = new Model();
                                    try {
                                        JSONObject object = (JSONObject) jsonArray.get(i);

                                        data.setBillerAccountName(object.getString(getString(R.string.biller_account_name)));
                                        data.setBillerAccountNumber(object.getString(getString(R.string.biller_account_number)));
                                        data.setBillerAccountType(object.getString(getString(R.string.biller_account_type)));
                                        data.setBillerCategory(object.getString(getString(R.string.biller_account_category)));
                                        data.setBillerId(object.getString(getString(R.string.biller_account_id)));

                                        models.add(data);

                                    } catch (JSONException e) {
                                        // Log.e(TAG, "the error: " + e.getMessage());

                                    }
                                }
                            }
                        }catch (JSONException e) {
                            e.printStackTrace();
                        }
                        mAdapter.notifyDataSetChanged();
                    }
                });
                    }
             }.start();
    }

}
