package com.ipayafrica.ipay.activities.activities;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.SharedPreff;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class HelpActivity extends AppCompatActivity {

    ImageView notification_back, notify_back;
    LinearLayout faqs, call, skype, email, signup;

    private final static int REQUEST_CODE_ASK_PERMISSIONS = 1;
    private static final String[] REQUIRED_SDK_PERMISSIONS = new String[] {
            Manifest.permission.CALL_PHONE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        faqs = (LinearLayout) findViewById(R.id.faqs);
        call = (LinearLayout) findViewById(R.id.call);
        skype = (LinearLayout) findViewById(R.id.skype);
        email = (LinearLayout) findViewById(R.id.email);
        signup = (LinearLayout) findViewById(R.id.signup);

        notification_back = (ImageView) findViewById(R.id.notification_back);
        notify_back       = (ImageView) findViewById(R.id.notify_back);

        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        /** faqs */
        faqs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HelpActivity.this,  getString(R.string.help_faq), Toast.LENGTH_SHORT).show();
            }
        });

        /** call */
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //call
                Intent callIntent =new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse(getString(R.string.help_tel)));
                startActivity(callIntent);
            }
        });

        /** skype chat */
        skype.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initiateSkypeUri(HelpActivity.this, getString(R.string.help_skype));
            }
        });

        /** send email */
        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(HelpActivity.this);

                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto", getString(R.string.support_email), null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Wallet Assistance (" + prefferences.get("wallet_id") + ")");
                startActivity(Intent.createChooser(emailIntent, getString(R.string.chooser_email_title)));

            }
        });

        /** sign up */
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(HelpActivity.this, LoginActivity.class);
                i.putExtra(getString(R.string.help_key_screen), getString(R.string.help_value_screen));
                startActivity(i);
                finish();
            }
        });

    }



    /**
     * Initiate the actions encoded in the specified URI.
     */
    public void initiateSkypeUri(Context myContext, String mySkypeUri) {

        // Make sure the Skype for Android client is installed.
        if (!isSkypeClientInstalled(myContext)) {
            Toast.makeText(myContext, getString(R.string.help_skype_install), Toast.LENGTH_SHORT).show();
            goToMarket(myContext);
            return;
        }

        // Create the Intent from our Skype URI.
        Uri skypeUri = Uri.parse(mySkypeUri);
        Intent myIntent = new Intent(Intent.ACTION_VIEW, skypeUri);

        // Restrict the Intent to being handled by the Skype for Android client only.
        myIntent.setComponent(new ComponentName(getString(R.string.help_skype_raider), getString(R.string.help_skype_raider_main)));
        myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        // Initiate the Intent. It should never fail because you've already established the
        // presence of its handler (although there is an extremely minute window where that
        // handler can go away).
        myContext.startActivity(myIntent);

        return;
    }

    /**
     * Determine whether the Skype for Android client is installed on this device.
     *
     * @param myContext The requesting view
     * @return
     */
    public boolean isSkypeClientInstalled(Context myContext) {
        PackageManager myPackageMgr = myContext.getPackageManager();
        try {
            myPackageMgr.getPackageInfo(getString(R.string.help_skype_raider), PackageManager.GET_ACTIVITIES);
        } catch (PackageManager.NameNotFoundException e) {
            return (false);
        }
        return (true);
    }

    /**
     * Install the Skype client through the market: URI scheme.
     *
     * @param myContext
     */
    public void goToMarket(Context myContext) {
        try {
            Uri marketUri = Uri.parse(getString(R.string.help_skype_market));
            Intent myIntent = new Intent(Intent.ACTION_VIEW, marketUri);
            myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            myContext.startActivity(myIntent);
        }catch (ActivityNotFoundException e){
            Toast.makeText(myContext, getString(R.string.help_skype_no_market), Toast.LENGTH_SHORT).show();
        }
    }


    /** request permission */
    protected void checkPermissions() {
        final List<String> missingPermissions = new ArrayList<String>();
        // check all required dynamic permissions
        for (final String permission : REQUIRED_SDK_PERMISSIONS) {
            final int result = ContextCompat.checkSelfPermission(this, permission);
            if (result != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }
        if (!missingPermissions.isEmpty()) {
            // request all missing permissions
            final String[] permissions = missingPermissions
                    .toArray(new String[missingPermissions.size()]);
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            final int[] grantResults = new int[REQUIRED_SDK_PERMISSIONS.length];
            Arrays.fill(grantResults, PackageManager.PERMISSION_GRANTED);
            onRequestPermissionsResult(REQUEST_CODE_ASK_PERMISSIONS, REQUIRED_SDK_PERMISSIONS,
                    grantResults);
        }
    }

}
