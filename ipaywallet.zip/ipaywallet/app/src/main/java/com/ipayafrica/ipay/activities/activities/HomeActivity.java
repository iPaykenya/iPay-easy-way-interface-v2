package com.ipayafrica.ipay.activities.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import androidx.annotation.NonNull;
import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.DeviceUtils;
import com.ipayafrica.ipay.activities.utils.Model;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.adapters.BanksAdaptor;
import com.ipayafrica.ipay.activities.utils.adapters.CachedBankAdaptor;
import com.ipayafrica.ipay.activities.utils.database.WalletDB;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {

    public ProgressDialog mAuthProgressDialog;

    //private Context mContext;
    Button home_pay_business, home_pay_water, home_pay_electricity, home_buy_internet,
            home_buy_airtime, home_pay_tv, home_send_money, home_donate, home_bank, TopUp, withDraw;
    ImageView go_to_profile;
    private Toast backtoast; //used on back pressed
    Boolean exit_app;

    public BottomNavigationItemView nav_home;

    public PopupWindow mPopupWindow;
    private Context mContext;
    private LinearLayout mLinearLayout;

    //ImageButton menu_bar;
    //Button mywallet, topup, withdraw;
    //ImageView main_menu;
    //int position;

    static HomeActivity instance;
    public static HomeActivity getInstace(){
        if(instance == null){
            instance = new HomeActivity ();
        }
        return instance;
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:

                    return true;

                case R.id.navigation_wallet:
                    startActivity(new Intent(HomeActivity.this, MyWalletActivity.class));
                    return true;

                case R.id.navigation_billers:
                    startActivity(new Intent(HomeActivity.this, BillersActivity.class));
                    return true;

            }
            return false;
        }
    };


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("");

        exit_app = false;
        instance = this;
        mContext= this;
        mLinearLayout = (LinearLayout) findViewById(R.id.myhome);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        nav_home = (BottomNavigationItemView) findViewById(R.id.navigation_home);

        //check if connected to internet
        if (!new DeviceUtils().isNetworkAvailable(this)){
            showAlertDialogNetwork(getString(R.string.check_internet), this);
            return;
        }

        //start loader
        mAuthProgressDialog = new ProgressDialog(this);
        mAuthProgressDialog.setMessage(getString(R.string.loader));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();


        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                //check if google recognises this device
                 new DeviceUtils().ifGooglePlayServicesValid(mContext);
            }
        }, 2000);


        //main_menu             = (ImageView) findViewById(R.id.image_menu);
        home_pay_business       = (Button) findViewById(R.id.home_pay_business);
        home_pay_water          = (Button) findViewById(R.id.home_pay_water);
        home_pay_electricity    = (Button) findViewById(R.id.home_pay_electricity);
        home_buy_internet       = (Button) findViewById(R.id.home_buy_internet);
        home_buy_airtime        = (Button) findViewById(R.id.home_buy_airtime);
        home_pay_tv             = (Button) findViewById(R.id.home_pay_tv);
        home_send_money         = (Button) findViewById(R.id.home_send_money);
        home_donate             = (Button) findViewById(R.id.home_donate);
        home_bank               = (Button) findViewById(R.id.home_bank);
        TopUp                   = (Button) findViewById(R.id.go_to_topUp);
        withDraw                = (Button) findViewById(R.id.go_to_withdraw);

        go_to_profile          = (ImageView) findViewById(R.id.go_to_profile);
//        add_banks               = (Button) findViewById(R.id.add_banks);
//
//
//        /** view banks */
//        add_banks.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i=new Intent(HomeActivity.this, QuickLoginActivity.class);
//                i.putExtra("screen", " getBanks");
//                startActivity(i);
//                return;
//            }
//        });

//        mywallet    = (Button) findViewById(R.id.mywallet);
//        topup       = (Button) findViewById(R.id.topup);
//        withdraw    = (Button) findViewById(R.id.withdrawal);
//        menu_bar    = (ImageButton) findViewById(R.id.imageButton);

//        mywallet.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(mContext, "loading wallet", Toast.LENGTH_SHORT).show();
//            }
//        });
//
        TopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, MyWalletActivity.class));
            }
        });

        withDraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, MyWalletActivity.class));
            }
        });

        go_to_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent profile = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(profile);
            }
        });
//
//        main_menu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showPopupMenu(main_menu, position);
//            }
//        });

        home_pay_business.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent biz = new Intent(HomeActivity.this, PayBizActivity.class);
                biz.putExtra(getString(R.string.home_screen_key), getString(R.string.home_screen_value));
                startActivity(biz);
                //startActivity(new Intent(HomeActivity.this, PayBizActivity.class));
            }
        });

        home_donate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent biz = new Intent(HomeActivity.this, PayBizActivity.class);
                biz.putExtra(getString(R.string.home_screen_key), getString(R.string.home_donate_value));
                startActivity(biz);
            }
        });

        home_pay_water.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent water = new Intent(HomeActivity.this, PayBillsActivity.class);
                water.putExtra(getString(R.string.home_screen_key), getString(R.string.home_water_value));
                startActivity(water);

            }
        });

        home_pay_electricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent electricity = new Intent(HomeActivity.this, PayBillsActivity.class);
                electricity.putExtra(getString(R.string.home_screen_key), getString(R.string.home_electronic_value));
                startActivity(electricity);
            }
        });

        home_buy_internet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent internet = new Intent(HomeActivity.this, PayBillsActivity.class);
                internet.putExtra(getString(R.string.home_screen_key), getString(R.string.home_internet_value));
                startActivity(internet);
            }
        });

        home_buy_airtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent airtime = new Intent(HomeActivity.this, PayBillsActivity.class);
                airtime.putExtra(getString(R.string.home_screen_key), getString(R.string.home_airtime_value));
                startActivity(airtime);
            }
        });


        home_pay_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent water = new Intent(HomeActivity.this, PayBillsActivity.class);
                water.putExtra(getString(R.string.home_screen_key), getString(R.string.home_tv_value));
                startActivity(water);
            }
        });

        home_send_money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent water = new Intent(HomeActivity.this, PayBillsActivity.class);
                water.putExtra(getString(R.string.home_screen_key), getString(R.string.home_send_money_value));
                startActivity(water);
            }
        });

        home_bank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(mContext);

                String walletid     =  String.valueOf(prefferences.get(getString(R.string.home_wallet_id_value)));
                /**initiate sqlite*/
                WalletDB db = new WalletDB(mContext);
                JSONArray banks = db.getAllBanks(walletid);
                if (banks.length() <= 0)
                {
                    String msg = getString(R.string.home_no_bank_value);
                    String positive_button = getString(R.string.home_add_bank_value);
                    String negative_button = getString(R.string.home_cancel_bank_value);
                    subscribeDialog(msg, positive_button, negative_button);
                    return;
                }
                //call popup to display accounts
                cachedBanksPopup(banks);

            }
        });
    }

    public void onBackPressed() {

        nav_home.performClick();
//        if(backtoast!=null&&backtoast.getView().getWindowToken()!=null) {
//            //other stuff...
//            super.onBackPressed();
//            finish();
//        } else {
//            backtoast = Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT);
//            backtoast.show();
//        }

        if (exit_app) {
            super.onBackPressed();
            return;
        }

        this.exit_app = true;
        Toast toast = Toast.makeText(mContext,getString(R.string.home_exit_value), Toast.LENGTH_SHORT);
        //toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                exit_app=false;
            }
        }, 2000);

    }

    public void onResume() {
        super.onResume();
        nav_home.performClick();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {

            case R.id.profile:
                Intent profile = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(profile);
                return true;

            case R.id.notification:
                Intent notify = new Intent(HomeActivity.this, NotificationActivity.class);
                startActivity(notify);
                return true;

            case R.id.help:
                Intent help = new Intent(HomeActivity.this, HelpActivity.class);
                startActivity(help);
                    return true;

            case R.id.share:
                shareTextUrl();
                return true;

//            case R.id.refer:
//                Toast.makeText(HomeActivity.this, "refer coming soon", Toast.LENGTH_SHORT).show();
//                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void shareTextUrl() {
        Intent share = new Intent(android.content.Intent.ACTION_SEND);
        share.setType("text/plain");
        share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);

        share.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.home_share_title_value));
        share.putExtra(Intent.EXTRA_TEXT, getString(R.string.home_share_value));

        startActivity(Intent.createChooser(share, getString(R.string.home_share_title_context_value)));
    }


    /**user bank account popup */
    private void banksPopup(JSONArray bankdata) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutbankspopup,null, false);

        ArrayList<Model> models;
        BanksAdaptor mAdapter;

        ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

        /*** <----recycler code---- ***/
        RecyclerView banksRecycler = (RecyclerView) customView.findViewById(R.id.banksRecycler);

        banksRecycler.setHasFixedSize(true);
        models = new ArrayList<>();
        mAdapter = new BanksAdaptor(mContext, models);
        @SuppressLint("WrongConstant") LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        banksRecycler.setLayoutManager(mLayoutManager);
        banksRecycler.setItemAnimator(new DefaultItemAnimator());
        banksRecycler.setAdapter(mAdapter);
        /*** ----recycler code />---- ***/

        /**extract json array from db */
        JSONArray jsonArray;
        jsonArray = bankdata;

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject object = null;
            Model data = new Model();
            try {
                object = (JSONObject) jsonArray.get(i);
                data.setBankId(object.getString(getString(R.string.home_id_value)));
                data.setBankName(object.getString(getString(R.string.home_bank_name_value)));
                data.setBankNickname(object.getString(getString(R.string.home_bank_nickname_value)));
                data.setBankPaybill(object.getString(getString(R.string.home_bank_paybill_value)));
                models.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        mAdapter.notifyDataSetChanged();

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the withdrawpopup window
                mPopupWindow.dismiss();
            }
        });

        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);
        mPopupWindow.showAtLocation(mLinearLayout, Gravity.CENTER,0,0);

    }


    /**user cached bank accounts popup */
    private void cachedBanksPopup(JSONArray banks) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutbankscachedpopup,null, false);

        ArrayList<Model> models;
        CachedBankAdaptor mAdapter;

        ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

        /*** <----recycler code---- ***/
        RecyclerView bankscachedRecycler = (RecyclerView) customView.findViewById(R.id.banksCachedRecycler);

        bankscachedRecycler.setHasFixedSize(true);
        models = new ArrayList<>();
        mAdapter = new CachedBankAdaptor(mContext, models);
        @SuppressLint("WrongConstant") LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        bankscachedRecycler.setLayoutManager(mLayoutManager);
        bankscachedRecycler.setItemAnimator(new DefaultItemAnimator());
        bankscachedRecycler.setAdapter(mAdapter);
        /*** ----recycler code />---- ***/

        /**extract json array from db */
        JSONArray jsonArray;
        jsonArray = banks;

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject object = null;
            Model data = new Model();
            try {
                object = (JSONObject) jsonArray.get(i);
                data.setBankName(object.getString(getString(R.string.home_bank_name_two_value)));
                data.setBankNickname(object.getString(getString(R.string.home_bank_nickname_two_value)));
                data.setBankPaybill(object.getString(getString(R.string.home_bank_paybill_two_value)));
                data.setBankAccountName(object.getString(getString(R.string.home_bank_accountname_two_value)));
                data.setBankAccountNumber(object.getString(getString(R.string.home_bank_accountnumber_two_value)));
                models.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        mAdapter.notifyDataSetChanged();

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the withdrawpopup window
                mPopupWindow.dismiss();
            }
        });

        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);
        mPopupWindow.showAtLocation(mLinearLayout, Gravity.CENTER,0,0);

    }


    //TODO this method is not used to be implemented baadaye
    /** network call for banks */
    public void getBanks()
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(HomeActivity.this);
        mAuthProgressDialog.setMessage(getString(R.string.home_processing_value));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                //form hashmap
                Map<String, String> params = new HashMap<String, String>();

                HashMap<String, String> header = new HashMap<String, String>();

                //send data to volley
                String url = getString(R.string.baseUrl)+"banks";

                VolleyStringRequest volley = new VolleyStringRequest();
                volley.getData(HomeActivity.this, params, header, url, new VolleyCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        //process results
                        JSONObject oprator = null;

                        try {

                            oprator = new JSONObject(result);

                            String header_status = oprator.getString(getString(R.string.home_header_status_value));

                            if (header_status.toString().trim().equals(getString(R.string.home_header_status_200))) {

                                JSONArray jsonArray = oprator.getJSONArray(getString(R.string.home_status_data_200));
                                if (jsonArray.length() > 0)
                                {
                                    banksPopup(jsonArray);
                                }else{
                                    Toast.makeText(mContext, getString(R.string.home_status_empty_200), Toast.LENGTH_LONG).show();
                                }
                            }
                        }catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        }.start();
    }


    /** dialog */
    private void subscribeDialog(String msg, String positive_button, String negative_button)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this, R.style.AppCompatAlertDialogStyle);

        builder.setMessage(""+msg);

        builder.setPositiveButton(""+positive_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Intent i=new Intent(HomeActivity.this, QuickLoginActivity.class);
                i.putExtra(getString(R.string.home_screen_key), " "+getString(R.string.home_get_Banks));
                startActivity(i);
                return;
            }
        });

        builder.setNegativeButton(""+negative_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setCancelable(false);
        builder.show();
    }

    //dialog if network is not on
    public void showAlertDialogNetwork(String msg, Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AppCompatAlertDialogStyle);

        builder.setMessage(""+msg);

        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
                ((Activity)context).finish();
                return;
            }
        });

        builder.setCancelable(false);
        builder.show();
    }

//    private void showPopupMenu(View view, int position) {
//        // inflate menu
//        PopupMenu popup = new PopupMenu(view.getContext(),view );
//        MenuInflater inflater = popup.getMenuInflater();
//        inflater.inflate(R.menu.main_menu, popup.getMenu());
//        popup.setOnMenuItemClickListener(new MyMenuItemClickListener(position));
//        popup.show();
//    }

//    class MyMenuItemClickListener implements PopupMenu.OnMenuItemClickListener {
//
//        private int position;
//        public MyMenuItemClickListener(int positon) {
//            this.position=positon;
//        }
//
//        @Override
//        public boolean onMenuItemClick(MenuItem menuItem) {
//
//            switch (menuItem.getItemId()) {
//
//                case R.id.help:
//                    Toast.makeText(mContext, "help coming soon", Toast.LENGTH_SHORT).show();
//                    return true;
//
//                case R.id.share:
//                    Toast.makeText(mContext, "share coming soon", Toast.LENGTH_SHORT).show();
//                    return true;
//
//                case R.id.refer:
//                    Toast.makeText(mContext, "refer coming soon", Toast.LENGTH_SHORT).show();
//                    return true;
//
//                default:
//            }
//            return false;
//        }
//    }

}
