package com.ipayafrica.ipay.activities.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.iid.FirebaseInstanceId;
import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.AES_Cipher;
import com.ipayafrica.ipay.activities.utils.DeviceUtils;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.FormValidation;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyValidation;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    EditText phoneField, passwordField, sign_fnameField, signlnameField, sign_phoneField,
            sign_passwordField, repeatPasswordField, referralCodeField, phone_number;
    CheckBox check_terms_conditions;
    Button to_register, to_go_back, loginButton, registerButton, to_forgot_password_view, forgot_go_back, forgot_send_Button, helpLogin;
    LinearLayout login, signin, forgot;

    private ProgressDialog mAuthProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phoneField      = (EditText) findViewById(R.id.phoneField);
        passwordField   = (EditText) findViewById(R.id.passwordField);

        sign_fnameField     = (EditText) findViewById(R.id.fnameField);
        signlnameField      = (EditText) findViewById(R.id.lnameField);
        sign_phoneField     = (EditText) findViewById(R.id.sign_phoneField);
        sign_passwordField  = (EditText) findViewById(R.id.sign_passwordField);
        repeatPasswordField = (EditText) findViewById(R.id.repeatPasswordField);
        referralCodeField   = (EditText) findViewById(R.id.referralCodeField);
        phone_number        = (EditText) findViewById(R.id.phone_number);

        check_terms_conditions = (CheckBox) findViewById(R.id.check_terms_conditions);

        to_register     = (Button) findViewById(R.id.to_register_view);
        to_go_back      = (Button) findViewById(R.id.to_go_back);
        loginButton     = (Button) findViewById(R.id.loginButton);
        registerButton  = (Button) findViewById(R.id.registerButton);
        to_forgot_password_view  = (Button) findViewById(R.id.to_forgot_password_view);
        forgot_go_back  = (Button) findViewById(R.id.forgot_go_back);
        forgot_send_Button  = (Button) findViewById(R.id.forgot_send_Button);
        helpLogin  = (Button) findViewById(R.id.helpLogin);

        login   = (LinearLayout) findViewById(R.id.login);
        signin  = (LinearLayout) findViewById(R.id.signin);
        forgot  = (LinearLayout) findViewById(R.id.forgot_password);

        new DeviceUtils().ifGooglePlayServicesValid(this);

        helpLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent help = new Intent(LoginActivity.this, HelpActivity.class);
                startActivity(help);
            }
        });


        /** to which screen after login ***/
        String nextscreen = null;
        Intent i= getIntent();
        Bundle screen = i.getExtras();
        if(screen!=null)
        {
            nextscreen =(String) screen.get(getString(R.string.login_key_screen));
        }

        if (nextscreen.equals(getString(R.string.login_signup)))
        {
            login.setVisibility(View.GONE);
            signin.setVisibility(View.VISIBLE);
            to_go_back.setVisibility(View.GONE);
            return;
        }

        /** invoke methods **/
        layoutExchange();
        buttonAction(nextscreen);
    }

    /** what user sees **/
    private void layoutExchange()
    {
        to_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login.setVisibility(View.GONE);
                signin.setVisibility(View.VISIBLE);
                forgot.setVisibility(View.GONE);
                sign_fnameField.requestFocus();
            }
        });

        to_go_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signin.setVisibility(View.GONE);
                login.setVisibility(View.VISIBLE);
                forgot.setVisibility(View.GONE);
                phoneField.requestFocus();
            }
        });

        to_forgot_password_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signin.setVisibility(View.GONE);
                login.setVisibility(View.GONE);
                forgot.setVisibility(View.VISIBLE);
                phone_number.requestFocus();
            }
        });

        forgot_go_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signin.setVisibility(View.GONE);
                login.setVisibility(View.VISIBLE);
                forgot.setVisibility(View.GONE);
                phoneField.requestFocus();
            }
        });

    }

    /** all activity buttons **/
    private void buttonAction(final String nextscreen)
    {
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login(nextscreen);
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });

        forgot_send_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (FormValidation.phoneValidationKe(phone_number.getText().toString().trim()) == false) {
                    phone_number.setError(getString(R.string.login_invalid_phone));
                    phone_number.requestFocus();
                    return;
                }
                //else call resent password
                forgotPassword(phone_number.getText().toString().trim());
            }
        });
    }

    private void register()
    {

        //get the data && validate
        String fname        = sign_fnameField.getText().toString().trim();
        String sname        = signlnameField.getText().toString().trim();
        String tel          = sign_phoneField.getText().toString().trim();
        String password     = sign_passwordField.getText().toString().trim();
        String conf_pass    = repeatPasswordField.getText().toString().trim();


        if (FormValidation.nameValidation(fname) == false) {
            sign_fnameField.setError(getString(R.string.login_invalid_name));
            sign_fnameField.requestFocus();
            return;
        }

        if (FormValidation.nameValidation(sname) == false) {
            signlnameField.setError(getString(R.string.login_invalid_name));
            signlnameField.requestFocus();
            return;
        }

        if (FormValidation.phoneValidationKe(tel) == false) {
            sign_phoneField.setError(getString(R.string.login_invalid_phone));
            sign_phoneField.requestFocus();
            return;
        }

        if (FormValidation.passwordValidation(password) == false) {
            sign_passwordField.setError(getString(R.string.login_invalid_password));
            sign_passwordField.requestFocus();
            return;
        }

        if (FormValidation.passwordValidation(conf_pass) == false) {
            repeatPasswordField.setError(getString(R.string.login_invalid_password));
            repeatPasswordField.requestFocus();
            return;
        }

        if (!password.equals(conf_pass))
        {
            sign_passwordField.setError(getString(R.string.login_password_mismatch));
            repeatPasswordField.setError(getString(R.string.login_password_mismatch));
            repeatPasswordField.requestFocus();
            return;
        }

        if (!check_terms_conditions.isChecked())
        {
            check_terms_conditions.setError(getString(R.string.login_read_accept));
            check_terms_conditions.requestFocus();
            return;
        }


        //form hashmap
        Map<String, String> params = new HashMap<>();
        params.put(getString(R.string.pass_fname), fname);
        params.put(getString(R.string.pass_lname), sname);
        params.put(getString(R.string.pass_phone), FormValidation.phonePrefixKe(tel));
        params.put(getString(R.string.pass_dob), "");
        params.put(getString(R.string.pass_country_id), getString(R.string.login_country_id));
        params.put(getString(R.string.pass_password), password);
        params.put(getString(R.string.pass_referrer_code), ""+referralCodeField.getText().toString().trim());
        params.put(getString(R.string.pass_device), getString(R.string.the_device));

        HashMap<String, String> header = new HashMap<>();
        header.put(getString(R.string.pass_Authorization), getString(R.string.pass_Bearer)+" ");

        //send data to volley
//        String url = getString(R.string.baseUrl)+"authorization";
        String url = getString(R.string.baseUrl)+getString(R.string.login_api_register);


        postData(LoginActivity.this, params, header, url, new VolleyCallBack() {
            @Override
            public void onSuccess(String result) {
                //send results to shared-pref
                Toast.makeText(LoginActivity.this, "", Toast.LENGTH_SHORT).show();

            }
        });
    }

    //login here with volley-call-back
    private void login(final String nextscreen)
    {
        //get the data && validate
        String tel      = phoneField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (FormValidation.phoneValidationKe(tel) == false) {
            phoneField.setError(getString(R.string.login_invalid_phone));
            phoneField.requestFocus();
            return;
        }

        if (FormValidation.passwordValidation(password) == false) {
            passwordField.setError(getString(R.string.login_invalid_password));
            passwordField.requestFocus();
            return;
        }

        //form hashmap
        Map<String, String> params = new HashMap<>();
        params.put(getString(R.string.pass_phone), FormValidation.phonePrefixKe(tel));
        params.put(getString(R.string.pass_password), password);
        params.put(getString(R.string.pass_f_token), FirebaseInstanceId.getInstance().getToken());
        params.put(getString(R.string.pass_device), getString(R.string.the_device));

        HashMap<String, String> header = new HashMap<>();
        header.put(getString(R.string.pass_Authorization), getString(R.string.pass_Bearer)+" ");

        //send data to volley
//        String url = getString(R.string.baseUrl)+"authorization";
        String url = getString(R.string.baseUrl)+getString(R.string.login_api_authorization);

        postData(LoginActivity.this, params, header, url, new VolleyCallBack() {
            @Override
            public void onSuccess(String result) {
                //send results to shared-pref
                SharedPreff pref = new SharedPreff();
                pref.sharedPreffLogin(LoginActivity.this, result, nextscreen);

            }
        });
    }

    public void forgotPassword(final String phone){

        Map<String, String> params = new HashMap<>();
        params.put(getString(R.string.pass_phone), FormValidation.phonePrefixKe(phone));
        params.put(getString(R.string.pass_device), getString(R.string.the_device));

        HashMap<String, String> header = new HashMap<>();
        header.put(getString(R.string.pass_Authorization), getString(R.string.pass_Bearer)+" ");


        //send data to volley
//        String url = getString(R.string.baseUrl)+"authorization";
        String url = getString(R.string.baseUrl)+getString(R.string.login_api_forgotpassword);


        postData(LoginActivity.this, params, header, url, new VolleyCallBack() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.getString(getString(R.string.home_header_status_value)).trim().equals(getString(R.string.home_header_status_200))){
                        Toast.makeText(LoginActivity.this, getString(R.string.login_reset_sms)+phone, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void postData(final Context contxt, final Map<String, String> params, final HashMap<String, String> header, String url, final VolleyCallBack callback) {

        String my_key = null, my_iv = null;
        ApplicationInfo ai = null;
        try {
            ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            my_key = bundle.getString(getString(R.string.login_my_key));
            my_iv = bundle.getString(getString(R.string.login_my_iv));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        /**call encryption func*/
        JSONObject data = new JSONObject(params);
        AES_Cipher aes_cipher = new AES_Cipher(this);
        final String encrypted = aes_cipher.encrypt(""+data, my_key, my_iv);
        /** encryption end*/


        mAuthProgressDialog = new ProgressDialog(contxt);
        mAuthProgressDialog.setMessage(getString(R.string.login_load));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        StringRequest request = new StringRequest(Request.Method.POST, ""+url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mAuthProgressDialog.hide();

                        callback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                mAuthProgressDialog.hide();
                VolleyValidation.volleyErrorResponseLogin(contxt, error);

            }

        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parameters = new HashMap<>();
                parameters.put(getString(R.string.login_data), encrypted);
                return parameters;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> map = header;
                return map;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(contxt);
        requestQueue.add(request);

    }
}
