package com.ipayafrica.ipay.activities.activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.FormValidation;
import com.ipayafrica.ipay.activities.utils.Model;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.adapters.StatementAdaptor;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class MyWalletActivity extends AppCompatActivity {

    ImageView notification_back, notify_back;
    TextView mywallet_username, mywallet_phone, wallet_amount, wallet_amount_asat;
    LinearLayout wallet_topup, wallet_withdraw, wallet_logout, wallet_balance_layout, wallet_main, wallet_visaMastercard,
            wallet_sendmoney, wallet_help, wallet_profile, wallet_statement;
    Button wallet_balance_button, visaViewDone;
    EditText amount, Wallet_Card_Amount, Wallet_Card_Number, Wallet_Card_Cvv, Wallet_Card_month, Wallet_Card_year, Wallet_fName, Wallet_lName;
    Spinner Wallet_country_spinner;
    ImageButton balanceclose;

    //withdrawpopup
    public PopupWindow mPopupWindow;
    private Context mContext;
    private RelativeLayout mRelativeLayout;

    ArrayList<Model> models;
    StatementAdaptor mAdapter;

    static MyWalletActivity instance;
    public static MyWalletActivity getInstace(){
        if(instance == null){
            instance = new MyWalletActivity ();
        }
        return instance;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_wallet);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        instance = this;
        mContext= this;
        mRelativeLayout=(RelativeLayout) findViewById(R.id.wallet_home);

        Wallet_Card_Amount  = (EditText) findViewById(R.id.Wallet_Card_Amount);
        Wallet_Card_Number  = (EditText) findViewById(R.id.Wallet_Card_Number);
        Wallet_Card_Cvv     = (EditText) findViewById(R.id.Wallet_Card_Cvv);
        Wallet_Card_month   = (EditText) findViewById(R.id.Wallet_Card_month);
        Wallet_Card_year    = (EditText) findViewById(R.id.Wallet_Card_year);
        Wallet_fName        = (EditText) findViewById(R.id.Wallet_fName);
        Wallet_lName        = (EditText) findViewById(R.id.Wallet_lName);

        mywallet_username   = (TextView) findViewById(R.id.mywallet_username);
        mywallet_phone      = (TextView) findViewById(R.id.mywallet_phone);
        wallet_amount       = (TextView) findViewById(R.id.wallet_amount);
        wallet_amount_asat  = (TextView) findViewById(R.id.wallet_amount_asat);

        wallet_withdraw         = (LinearLayout) findViewById(R.id.wallet_withdraw);
        wallet_topup            = (LinearLayout) findViewById(R.id.wallet_topup);
        wallet_profile          = (LinearLayout) findViewById(R.id.wallet_profile);
        wallet_sendmoney        = (LinearLayout) findViewById(R.id.wallet_sendmoney);
        wallet_statement        = (LinearLayout) findViewById(R.id.wallet_statement);
        wallet_help             = (LinearLayout) findViewById(R.id.wallet_help);
        wallet_logout           = (LinearLayout) findViewById(R.id.wallet_logout);
        wallet_balance_layout   = (LinearLayout) findViewById(R.id.wallet_balance_layout);
        wallet_main             = (LinearLayout) findViewById(R.id.wallet_main);
        wallet_visaMastercard   = (LinearLayout) findViewById(R.id.wallet_visaMastercard);

        wallet_balance_button   = (Button) findViewById(R.id.wallet_balance_button);
        visaViewDone            = (Button) findViewById(R.id.visaViewDone);

        notification_back = (ImageView) findViewById(R.id.notification_back);
        notify_back       = (ImageView) findViewById(R.id.notify_back);

        balanceclose = (ImageButton) findViewById(R.id.balanceclose);

        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });

        /** hide balance */
        balanceclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wallet_balance_layout.setVisibility(View.GONE);
                wallet_balance_button.setVisibility(View.VISIBLE);
            }
        });

        //get Shared pref
        SharedPreff pref = new SharedPreff();
        Map prefferences = pref.getSharedPref(MyWalletActivity.this);

        if (!prefferences.get(getString(R.string.wallet_wallet_id)).equals("null"))
        {
            mywallet_username.setText(getString(R.string.wallet_welcome)+prefferences.get(getString(R.string.wallet_fname)) );
            mywallet_phone.setText(""+prefferences.get(getString(R.string.wallet_wallet_id)) );
        }else {

            Intent i=new Intent(MyWalletActivity.this, LoginActivity.class);
            i.putExtra(getString(R.string.wallet_screen), getString(R.string.wallet_mywallet));
            startActivity(i);
            //startActivity(new Intent(MyWalletActivity.this, LoginActivity.class));
            finish();
        }

        /** topup **/
        wallet_topup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topupPopup();
            }
        });

        /** visa done button */
        visaViewDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String card_amount  = Wallet_Card_Amount.getText().toString().trim();
                String card_number  = Wallet_Card_Number.getText().toString().trim();
                String card_cvv     = Wallet_Card_Cvv.getText().toString().trim();
                String card_month   = Wallet_Card_month.getText().toString().trim();
                String card_year    = Wallet_Card_year.getText().toString().trim();
                String wallet_fname = Wallet_fName.getText().toString().trim();
                String wallet_lname = Wallet_lName.getText().toString().trim();

                if (FormValidation.amountValidation(card_amount) == false) {
                    Wallet_Card_Amount.setError(getString(R.string.wallet_invalid_amount));
                    return;
                }

                if (FormValidation.cardNumberValidation(card_number) == false) {
                    Wallet_Card_Number.setError(getString(R.string.wallet_invalid_card));
                    return;
                }

                if (FormValidation.cardCvvValidation(card_cvv) == false) {
                    Wallet_Card_Cvv.setError(getString(R.string.wallet_invalid_cvv));
                    return;
                }

                if (FormValidation.cardMonthValidation(card_month) == false) {
                    Wallet_Card_month.setError(getString(R.string.wallet_invalid_month));
                    return;
                }

                if (FormValidation.cardYearValidation(card_year) == false) {
                    Wallet_Card_year.setError(getString(R.string.wallet_invalid_year));
                    return;
                }

                if (FormValidation.nameValidation(wallet_fname) == false) {
                    Wallet_fName.setError(getString(R.string.wallet_invalid_name));
                    return;
                }

                if (FormValidation.nameValidation(wallet_lname) == false) {
                    Wallet_lName.setError(getString(R.string.wallet_invalid_name));
                    return;
                }

                //call quick login
                Intent i=new Intent(MyWalletActivity.this, QuickLoginActivity.class);
                i.putExtra(getString(R.string.wallet_screen), getString(R.string.wallet_card_topup));
                startActivity(i);

            }
        });

        /** withdraw **/
        wallet_withdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                withdrawpopup();
            }
        });

        /** wallet balance **/
        wallet_balance_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //call quick login
                Intent i=new Intent(MyWalletActivity.this, QuickLoginActivity.class);
                i.putExtra(getString(R.string.wallet_screen), getString(R.string.wallet_balance));
                startActivity(i);
            }
        });

        /** send money */
        wallet_sendmoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent water = new Intent(MyWalletActivity.this, PayBillsActivity.class);
                water.putExtra(getString(R.string.wallet_screen), getString(R.string.wallet_send_money));
                startActivity(water);
            }
        });

        /** profile */
        wallet_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent profile = new Intent(MyWalletActivity.this, ProfileActivity.class);
                startActivity(profile);
            }
        });

        /** statement/history */
        wallet_statement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /** get quick login **/
                Intent i=new Intent(MyWalletActivity.this, QuickLoginActivity.class);
                i.putExtra(getString(R.string.wallet_screen), getString(R.string.wallet_statement));
                startActivity(i);
            }
        });


        /** help */
        wallet_help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent help = new Intent(MyWalletActivity.this, HelpActivity.class);
                startActivity(help);
            }
        });


        /** logout **/

        wallet_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreff preff = new SharedPreff();
                preff.clearSharedPref(MyWalletActivity.this);
                finish();
            }
        });

    }

    public void wallet_balance()
    {
        wallet_balance_button.setVisibility(View.GONE);
        wallet_balance_layout.setVisibility(View.VISIBLE);

        //get Shared pref
        SharedPreff pref = new SharedPreff();
        Map prefferences = pref.getSharedPref(MyWalletActivity.this);

        mywallet_username.setText(getString(R.string.wallet_welcome)+prefferences.get(getString(R.string.wallet_fname)) );
        mywallet_phone.setText(""+prefferences.get(getString(R.string.wallet_wallet_id)));
        wallet_amount.setText(prefferences.get(getString(R.string.wallet_curr))+" "+prefferences.get(getString(R.string.wallet_balance)));
        wallet_amount_asat.setText(getString(R.string.wallet_asat)+" "+Calendar.getInstance().getTime());
    }

    private void topupPopup()
    {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutwallettopup,null);


        SharedPreff pref = new SharedPreff();
        final Map prefferences = pref.getSharedPref(MyWalletActivity.this);

        final LinearLayout buttonLayout = (LinearLayout) customView.findViewById(R.id.buttonLayout);

        final ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

        final Button mpesaViewDone      = (Button) customView.findViewById(R.id.mpesaViewDone);
        final Button airtelViewDone     = (Button) customView.findViewById(R.id.airtelViewDone);
        final Button pesa_linkViewDone  = (Button) customView.findViewById(R.id.pesa_linkViewDone);
        final Button ezzyViewDone       = (Button) customView.findViewById(R.id.ezzyViewDone);

        ImageButton mpesa       = (ImageButton) customView.findViewById(R.id.mpesa);
        ImageButton airtel      = (ImageButton) customView.findViewById(R.id.airtel);
        ImageButton pesalink    = (ImageButton) customView.findViewById(R.id.pesalink);
        ImageButton ezzy        = (ImageButton) customView.findViewById(R.id.ezzy);
        ImageButton visa        = (ImageButton) customView.findViewById(R.id.visa);

        final CardView mpesaCard    = (CardView) customView.findViewById(R.id.mpesaCard);
        final CardView airtelCard   = (CardView) customView.findViewById(R.id.airtelCard);
        final CardView pesalinkCard = (CardView) customView.findViewById(R.id.pesalinkCard);
        final CardView ezzyCard     = (CardView) customView.findViewById(R.id.ezzyCard);

        final TextView mpesa_6      = (TextView) customView.findViewById(R.id.mpesa_6);
        final TextView airtel_8     = (TextView) customView.findViewById(R.id.airtel_8);
        final TextView pesa_link_3  = (TextView) customView.findViewById(R.id.pesa_link_3);
        final TextView ezzy_4       = (TextView) customView.findViewById(R.id.ezzy_4);


        Wallet_country_spinner = (Spinner) findViewById(R.id.Wallet_country_spinner);

        mpesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = FormValidation.removePhonePrefixKe(String.valueOf(prefferences.get(getString(R.string.wallet_wallet_id))));
                mpesa_6.setText(getString(R.string.wallet_6)+ phone  +getString(R.string.wallet_6_account));
                closeButton.setVisibility(View.GONE);
                mpesaCard.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.GONE);
            }
        });

        airtel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = FormValidation.removePhonePrefixKe(String.valueOf(prefferences.get(getString(R.string.wallet_wallet_id))));
                airtel_8.setText(getString(R.string.wallet_8)+ phone  +getString(R.string.wallet_8_send));
                closeButton.setVisibility(View.GONE);
                airtelCard.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.GONE);
            }
        });

        pesalink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = FormValidation.removePhonePrefixKe(String.valueOf(prefferences.get(getString(R.string.wallet_wallet_id))));
                pesa_link_3.setText(getString(R.string.wallet_3)+ phone  +getString(R.string.wallet_3_pay));
                closeButton.setVisibility(View.GONE);
                pesalinkCard.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.GONE);
            }
        });

        ezzy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = FormValidation.removePhonePrefixKe(String.valueOf(prefferences.get(getString(R.string.wallet_wallet_id))));
                ezzy_4.setText(getString(R.string.wallet_4)+ phone  +getString(R.string.wallet_4_account));
                closeButton.setVisibility(View.GONE);
                ezzyCard.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.GONE);
            }
        });

        visa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = FormValidation.removePhonePrefixKe(String.valueOf(prefferences.get(getString(R.string.wallet_wallet_id))));
                mPopupWindow.dismiss();
                wallet_main.setVisibility(View.GONE);
                wallet_visaMastercard.setVisibility(View.VISIBLE);
            }
        });

        mpesaViewDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeButton.setVisibility(View.VISIBLE);
                mpesaCard.setVisibility(View.GONE);
                buttonLayout.setVisibility(View.VISIBLE);
            }
        });

        airtelViewDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeButton.setVisibility(View.VISIBLE);
                airtelCard.setVisibility(View.GONE);
                buttonLayout.setVisibility(View.VISIBLE);
            }
        });

        pesa_linkViewDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeButton.setVisibility(View.VISIBLE);
                pesalinkCard.setVisibility(View.GONE);
                buttonLayout.setVisibility(View.VISIBLE);
            }
        });

        ezzyViewDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeButton.setVisibility(View.VISIBLE);
                ezzyCard.setVisibility(View.GONE);
                buttonLayout.setVisibility(View.VISIBLE);
            }
        });


        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);


        // Set a click listener for the withdrawpopup window close button
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the withdrawpopup window
                mPopupWindow.dismiss();
                mRelativeLayout.setVisibility(view.VISIBLE);
            }
        });
        mPopupWindow.showAtLocation(mRelativeLayout, Gravity.CENTER,0,0);
    }

    private void withdrawpopup()
    {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutwalletwithdraw,null, false);

        amount          = (EditText) customView.findViewById(R.id.Wallet_withdraw_amount);
        Button action   = (Button) customView.findViewById(R.id.wallet_action_button);

        action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount_withdraw = amount.getText().toString().trim();
                if (FormValidation.amountValidation(amount_withdraw) == false) {
                    Toast.makeText(mContext, getString(R.string.wallet_invalid_amount), Toast.LENGTH_LONG).show();
                    return;
                }

                //call quick login
                Intent i=new Intent(mContext, QuickLoginActivity.class);
                i.putExtra(getString(R.string.wallet_screen), getString(R.string.wallet_withdraw));
                startActivity(i);

            }
        });


        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);

        // Get a reference for the custom view close button
        ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

        // Set a click listener for the withdrawpopup window close button
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the withdrawpopup window
                mPopupWindow.dismiss();
                mRelativeLayout.setVisibility(view.VISIBLE);
            }
        });
        mPopupWindow.showAtLocation(mRelativeLayout, Gravity.CENTER,0,0);
    }

    private void statementPopup(JSONArray jsonArray)
    {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layouthistorypopup,null, false);


        /*** <----recycler code---- ***/
        RecyclerView historyRecycler = (RecyclerView) customView.findViewById(R.id.historyRecycler);

        historyRecycler.setHasFixedSize(true);
        models = new ArrayList<>();
        mAdapter = new StatementAdaptor(mContext, models);
        @SuppressLint("WrongConstant") LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        historyRecycler.setLayoutManager(mLayoutManager);
        historyRecycler.setItemAnimator(new DefaultItemAnimator());
        historyRecycler.setAdapter(mAdapter);
        /*** ----recycler code />---- ***/



        //models.clear();
        for (int i = 0; i < jsonArray.length(); i++) {
            Model data = new Model();
            try {
                JSONObject object = (JSONObject) jsonArray.get(i);

                data.setStatementTransactionId(object.getString(getString(R.string.wallet_transaction_id)));
                data.setStatementAmount(object.getString(getString(R.string.wallet_amount)));
                data.setStatementCurr(object.getString(getString(R.string.wallet_curr)));
                data.setStatementDescription(object.getString(getString(R.string.wallet_description)));
                data.setStatementReference(object.getString(getString(R.string.wallet_reference)));
                data.setStatementChannel(object.getString(getString(R.string.wallet_channel)));
                data.setStatementDate(object.getString(getString(R.string.wallet_receivingdate)));

                models.add(data);

            } catch (JSONException e) {
                // Log.e(TAG, "the error: " + e.getMessage());

            }
        }
        mAdapter.notifyDataSetChanged();

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);

        // Get a reference for the custom view close button
        ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

        // Set a click listener for the withdrawpopup window close button
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the withdrawpopup window
                mPopupWindow.dismiss();
                mRelativeLayout.setVisibility(view.VISIBLE);
            }
        });
        mPopupWindow.showAtLocation(mRelativeLayout, Gravity.CENTER,0,0);
    }

    public void statement()
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(MyWalletActivity.this);
        mAuthProgressDialog.setMessage(getString(R.string.wallet_processing));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(MyWalletActivity.this);

                String token    =  String.valueOf(prefferences.get(getString(R.string.wallet_token)));

                //form hashmap
                Map<String, String> params = new HashMap<String, String>();

                HashMap<String, String> header = new HashMap<String, String>();
                header.put(getString(R.string.biller_key_authorization), getString(R.string.my_bearer) + token);

                //send data to volley
                String url = getString(R.string.baseUrl)+getString(R.string.wallet_api_activity);

                VolleyStringRequest volley = new VolleyStringRequest();
                volley.getData(MyWalletActivity.this, params, header, url, new VolleyCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        //process results
                        JSONObject oprator = null;
                        try {
                            oprator = new JSONObject(result);

                            String header_status = oprator.getString(getString(R.string.home_header_status_value));

                            if (header_status.toString().trim().equals(getString(R.string.home_header_status_200))) {
                                JSONArray jsonArray = oprator.getJSONArray(getString(R.string.wallet_account_details));
                                if (jsonArray.length() >= 1)
                                {
                                    statementPopup(jsonArray);
                                }else {
                                    Toast.makeText(mContext, getString(R.string.wallet_no_data), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        }.start();
    }

    public void walletWithdraw()
    {
        final String amount_withdraw    = amount.getText().toString().trim();

        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(MyWalletActivity.this);
        mAuthProgressDialog.setMessage(getString(R.string.wallet_processing));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(MyWalletActivity.this);

                //check wallet balance
                float balance = Float.valueOf((String) prefferences.get(getString(R.string.wallet_balance)));
                String curr = String.valueOf(prefferences.get(getString(R.string.wallet_curr)));
                String token = String.valueOf(prefferences.get(getString(R.string.wallet_token)));
                String phone_number = String.valueOf(prefferences.get(getString(R.string.wallet_wallet_id)));

                if ((balance - 30) < Integer.valueOf(amount_withdraw)) {
                    Toast.makeText(instance, getString(R.string.wallet_fund), Toast.LENGTH_LONG).show();
                    mPopupWindow.dismiss();
                    return;
                } else {

                    //form hashmap
                    Map<String, String> params = new HashMap<>();
                    params.put(getString(R.string.wallet_amount), amount_withdraw);

                    HashMap<String, String> header = new HashMap<>();
                    header.put(getString(R.string.biller_key_authorization), getString(R.string.my_bearer) + token);

                    //send data to volley
                    String url = getString(R.string.baseUrl) +getString(R.string.wallet_api_withdraw);

                    VolleyStringRequest volley = new VolleyStringRequest();
                    volley.postData(MyWalletActivity.this, params, header, url, new VolleyCallBack() {
                        @Override
                        public void onSuccess(String result) {
                            //process results
                            mPopupWindow.dismiss();
                            Toast.makeText(MyWalletActivity.this, "" + result, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }.start();
    }


    public void walletTopup()
    {
        final String card_amount  = Wallet_Card_Amount.getText().toString().trim();
        final String card_number  = Wallet_Card_Number.getText().toString().trim();
        final String card_cvv     = Wallet_Card_Cvv.getText().toString().trim();
        final String card_month   = Wallet_Card_month.getText().toString().trim();
        final String card_year    = Wallet_Card_year.getText().toString().trim();
        final String wallet_fname = Wallet_fName.getText().toString().trim();
        final String wallet_lname = Wallet_lName.getText().toString().trim();



        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(MyWalletActivity.this);
        mAuthProgressDialog.setMessage(getString(R.string.wallet_processing));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(MyWalletActivity.this);
                String token = String.valueOf(prefferences.get(getString(R.string.wallet_token)));
                String email = String.valueOf(prefferences.get(getString(R.string.wallet_email)));

                    //form hashmap
                    Map<String, String> parameters = new HashMap<>();
                    parameters.put(getString(R.string.wallet_amount), card_amount);
                    parameters.put(getString(R.string.wallet_email), email);
                    parameters.put(getString(R.string.wallet_cvv), card_cvv);
                    parameters.put(getString(R.string.wallet_expyear), card_year);
                    parameters.put(getString(R.string.wallet_expmonth), card_month);
                    parameters.put(getString(R.string.wallet_cardno), card_number);
                    parameters.put(getString(R.string.wallet_city), "NA");
                    parameters.put(getString(R.string.wallet_country), Wallet_country_spinner.getSelectedItem().toString());
                    parameters.put(getString(R.string.wallet_fname), wallet_fname);
                    parameters.put(getString(R.string.wallet_lname), wallet_lname);

                    HashMap<String, String> header = new HashMap<>();
                    header.put(getString(R.string.biller_key_authorization), getString(R.string.my_bearer) + token);

                    //send data to volley
                    String url = getString(R.string.baseUrl) +getString(R.string.wallet_topup);

                    VolleyStringRequest volley = new VolleyStringRequest();
                    volley.postData(MyWalletActivity.this, parameters, header, url, new VolleyCallBack() {
                        @Override
                        public void onSuccess(String result) {

                             wallet_visaMastercard.setVisibility(View.GONE);
                             wallet_main.setVisibility(View.VISIBLE);

                            //process results
                            Toast.makeText(MyWalletActivity.this, "" + result, Toast.LENGTH_SHORT).show();
                        }
                    });
            }
        }.start();
    }

}
