package com.ipayafrica.ipay.activities.activities;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.Model;
import com.ipayafrica.ipay.activities.utils.adapters.NotifyAdaptor;
import com.ipayafrica.ipay.activities.utils.database.WalletDB;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class NotificationActivity extends AppCompatActivity {

    ArrayList<Model> models;
    NotifyAdaptor mAdapter;

    ImageView notification_back, notify_back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        notification_back = (ImageView) findViewById(R.id.notification_back);
        notify_back       = (ImageView) findViewById(R.id.notify_back);


        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        /*** <----recycler code---- ***/
        RecyclerView notifyRecycler = (RecyclerView) findViewById(R.id.notificationrecycler);

        notifyRecycler.setHasFixedSize(true);
        models = new ArrayList<>();
        mAdapter = new NotifyAdaptor(NotificationActivity.this, models);
        @SuppressLint("WrongConstant") LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(NotificationActivity.this, LinearLayoutManager.VERTICAL, false);
        notifyRecycler.setLayoutManager(mLayoutManager);
        notifyRecycler.setItemAnimator(new DefaultItemAnimator());
        notifyRecycler.setAdapter(mAdapter);
        /*** ----recycler code />---- ***/

        getNotifications();
    }

    /**get notification from sqlite*/
    private void getNotifications()
    {
        /**initiate sqlite*/
        WalletDB db = new WalletDB(NotificationActivity.this);
        JSONArray notifydata = db.getNotifications();

        /**extract json array from db */
        JSONArray jsonArray;
        jsonArray = notifydata;

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject object = null;
            Model data = new Model();
            try {
                object = (JSONObject) jsonArray.get(i);
                data.setNotifyBody(object.getString(getString(R.string.notification_body)));
                data.setNotifyTitle(object.getString(getString(R.string.notification_title)));
                data.setNotifyTime(object.getString(getString(R.string.notification_time)));
                data.setNotifyId(object.getString(getString(R.string.notification_id)));
                data.setNotifyFlag(object.getString(getString(R.string.notification_flag)));
                models.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        mAdapter.notifyDataSetChanged();
    }

}
