package com.ipayafrica.ipay.activities.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.ContactsContract;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.CallIpay;
import com.ipayafrica.ipay.activities.utils.FormValidation;
import com.ipayafrica.ipay.activities.utils.Model;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.adapters.SendMoneyBankAdaptor;
import com.ipayafrica.ipay.activities.utils.database.WalletDB;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * this activity contains
 *  --> pay water @see water()
 *  --> pay electricity @see electricity()
 *  --> pay internet @see internet()
 *  --> pay Tv @see tv()
 *  --> buy airtime @see airtime()
 *  --> send money @see sendMoney()
 */

public class PayBillsActivity extends AppCompatActivity {

    LinearLayout water, electricity, pay_nairobi_water, payment_layout, bill_post_paid, bill_pre_paid,
            internet, pay_zuku_internet, tv, pay_dstv, pay_gotv, pay_zukutv, pay_starttimetv, airtime_layout,
            send_money_layout;
    ImageView notification_back, notify_back, payment_back, search_contacts, sendmoney_search_contacts, search_biller;
    TextView pay_title, contact_name, sendmoney_contact_name;
    EditText mybill_account_number, mybill_amount, buy_airtime, buy_amount, sendmoney_number, sendmoney_amount;
    Button pay_bill_button, pay_airtime_button, sendmoney__button;
    Button go_to_mywallet, go_to_topup, go_to_withdrawal;
    RadioGroup paymentOption, airtimepayoptions, operator, sendmoney;
    Spinner biller_list;
    private RadioButton radioButton, operator_radio, sendmoney_radio;
    final int PICK_CONTACT_BUY_AIRTIME = 1;
    final int PICK_CONTACT_SEND_MONEY = 2;

    private final static int REQUEST_CODE_ASK_PERMISSIONS = 1;

    //get the fields
    String account_to_pay, amount_to_pay;

    public PopupWindow mPopupWindow;
    private Context mContext;
    private LinearLayout mLinearLayout;

    static PayBillsActivity instance;
    public static PayBillsActivity getInstace(){
        if(instance == null){
            instance = new PayBillsActivity ();
        }
        return instance;
    }

    private static final String[] REQUIRED_SDK_PERMISSIONS = new String[] {
            Manifest.permission.READ_CONTACTS
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_bills);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mContext = this;
        mLinearLayout = (LinearLayout) findViewById(R.id.mybillpayment);
        instance = this;

        notification_back           = (ImageView) findViewById(R.id.notification_back);
        notify_back                 = (ImageView) findViewById(R.id.notify_back);
        payment_back                = (ImageView) findViewById(R.id.payment_back);
        search_contacts             = (ImageView) findViewById(R.id.search_contacts);
        sendmoney_search_contacts   = (ImageView) findViewById(R.id.sendmoney_search_contacts);
        search_biller               = (ImageView) findViewById(R.id.search_biller);

        pay_title                   = (TextView) findViewById(R.id.pay_bill_title);
        contact_name                = (TextView) findViewById(R.id.contact_name);
        sendmoney_contact_name      = (TextView) findViewById(R.id.sendmoney_contact_name);

        mybill_account_number   = (EditText) findViewById(R.id.mybill_account_number);
        mybill_amount           = (EditText) findViewById(R.id.mybill_amount);
        buy_airtime             = (EditText) findViewById(R.id.buy_airtime);
        buy_amount              = (EditText) findViewById(R.id.buy_amount);
        sendmoney_number        = (EditText) findViewById(R.id.sendmoney_number);
        sendmoney_amount        = (EditText) findViewById(R.id.sendmoney_amount);

        pay_bill_button     = (Button) findViewById(R.id.pay_bill_button);
        pay_airtime_button  = (Button) findViewById(R.id.pay_airtime_button);
        sendmoney__button   = (Button) findViewById(R.id.sendmoney__button);

        go_to_mywallet      = (Button) findViewById(R.id.mywallet);
        go_to_topup         = (Button) findViewById(R.id.topup);
        go_to_withdrawal    = (Button) findViewById(R.id.withdrawal);


        paymentOption       = (RadioGroup) findViewById(R.id.paymentOption);
        airtimepayoptions   = (RadioGroup) findViewById(R.id.airtimeoptions);
        operator            = (RadioGroup) findViewById(R.id.operator);
        sendmoney           = (RadioGroup) findViewById(R.id.sendmoney_radiogroup);

        water               = (LinearLayout) findViewById(R.id.water);
        electricity         = (LinearLayout) findViewById(R.id.electricity);
        payment_layout      = (LinearLayout) findViewById(R.id.payment_layout);
        pay_nairobi_water   = (LinearLayout) findViewById(R.id.pay_nairobi_water);
        bill_post_paid      = (LinearLayout) findViewById(R.id.bill_post_paid);
        bill_pre_paid       = (LinearLayout) findViewById(R.id.bill_pre_paid);
        internet            = (LinearLayout) findViewById(R.id.internet);
        pay_zuku_internet   = (LinearLayout) findViewById(R.id.pay_zuku_internet);
        tv                  = (LinearLayout) findViewById(R.id.tv);
        pay_dstv            = (LinearLayout) findViewById(R.id.pay_dstv);
        pay_gotv            = (LinearLayout) findViewById(R.id.pay_gotv);
        pay_zukutv          = (LinearLayout) findViewById(R.id.pay_zukutv);
        pay_starttimetv     = (LinearLayout) findViewById(R.id.pay_starttimetv);
        airtime_layout      = (LinearLayout) findViewById(R.id.airtime_layout);
        send_money_layout   = (LinearLayout) findViewById(R.id.send_money_layout);

        biller_list   = (Spinner) findViewById(R.id.biller_list);
        biller_list.setVisibility(View.GONE);

        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        /** call wallet activity */
        go_to_mywallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PayBillsActivity.this, MyWalletActivity.class));
                finish();
            }
        });
        go_to_topup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PayBillsActivity.this, MyWalletActivity.class));
                finish();
            }
        });
        go_to_withdrawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PayBillsActivity.this, MyWalletActivity.class));
                finish();
            }
        });

        /** invoke all methods **/
        screenExchange();
        searchBiller();

    }

    private void screenExchange()
    {
        //get extra
        Intent intent = getIntent();
        if (intent != null) {
            String currentScreen = intent.getStringExtra("screen");
            if (currentScreen.trim().equals("water_screen"))
            {
                water();
                return;
            }

            if (currentScreen.trim().equals("electricity_screen"))
            {
                electricity();
                return;
            }

            if (currentScreen.trim().equals("internet_screen"))
            {
                internet();
                return;
            }

            if (currentScreen.trim().equals("airtime_screen"))
            {
                airtime();
                return;
            }

            if (currentScreen.trim().equals("tv_screen"))
            {
                tv();
                return;
            }

            if (currentScreen.trim().equals("send_money_screen"))
            {
                sendMoney();
                return;
            }


            return;
        }

        Toast.makeText(this, "system error please try again.", Toast.LENGTH_SHORT).show();

    }

    //search fot biller
    private void searchBiller(){
        search_biller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /** get quick login **/
                Intent i=new Intent(PayBillsActivity.this, QuickLoginActivity.class);
                i.putExtra("screen", "select_billers");
                startActivity(i);
            }
        });
    }

    /** get billers */
    public void getBiller()
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(PayBillsActivity.this);
        mAuthProgressDialog.setMessage("processing please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(PayBillsActivity.this);

                String token    =  String.valueOf(prefferences.get("token"));

                //form hashmap
                Map<String, String> params = new HashMap<String, String>();

                HashMap<String, String> header = new HashMap<String, String>();
                header.put("Authorization", "Bearer " + token);

                //send data to volley
                String url = getString(R.string.baseUrl)+"wallet/billing/list/accounts";

                VolleyStringRequest volley = new VolleyStringRequest();
                volley.getData(PayBillsActivity.this, params, header, url, new VolleyCallBack() {
                    @Override
                    public void onSuccess(String result) {

                        //process results
                        JSONObject oprator = null;
                        try {

                            oprator = new JSONObject(result);

                            String header_status = oprator.getString("header_status");

                            if (header_status.toString().trim().equals("200")) {

                                JSONArray jsonArray = oprator.getJSONArray("account_details");

                                List<String> list = new ArrayList<>();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    try {

                                        JSONObject object = (JSONObject) jsonArray.get(i);

                                        list.add(object.getString("account_name")+" ("+object.getString("account_number")+")");

                                    } catch (JSONException e) {
                                        // Log.e(TAG, "the error: " + e.getMessage());

                                    }
                                }

                                if (list.size()>0) {
                                    biller_list.setVisibility(View.VISIBLE);
                                    ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(PayBillsActivity.this, android.R.layout.simple_spinner_item, list);
                                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                    biller_list.setAdapter(spinnerAdapter);
                                    spinnerAdapter.notifyDataSetChanged();

                                }else {
                                    Toast.makeText(mContext, "No biller account was found!", Toast.LENGTH_LONG).show();
                                }
                            }
                        }catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        }.start();
    }


    private void water()
    {
        water.setVisibility(View.VISIBLE);
        electricity.setVisibility(View.GONE);
        internet.setVisibility(View.GONE);
        search_biller.setVisibility(View.VISIBLE);

        pay_nairobi_water.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title        = "Pay Nairobi water bill";
                String account      = "Meter number";
                String amount       = "amount";
                String screenToLoad = "pay_water";
                String bill_operator = "nairobi_water";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);
            }
        });

        payment_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mybill_account_number.setText("");
                mybill_amount.setText("");

                water.setVisibility(View.VISIBLE);
                electricity.setVisibility(View.GONE);
                payment_layout.setVisibility(View.GONE);
            }
        });
    }

    private void electricity()
    {
        water.setVisibility(View.GONE);
        electricity.setVisibility(View.VISIBLE);
        internet.setVisibility(View.GONE);
        search_biller.setVisibility(View.VISIBLE);

        bill_post_paid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title        = "Pay KPLC postpaid bill";
                String account      = "Meter number";
                String amount       = "amount";
                String screenToLoad = "postpaid";
                String bill_operator = "kplc_postpaid";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);
            }
        });


        bill_pre_paid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title = "Buy KPLC prepaid (Tokens)";
                String account = "Meter number";
                String amount = "amount";
                String screenToLoad = "prepaid";
                String bill_operator = "kplc_prepaid";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);

            }
        });

        payment_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mybill_account_number.setText("");
                mybill_amount.setText("");

                water.setVisibility(View.GONE);
                electricity.setVisibility(View.VISIBLE);
                payment_layout.setVisibility(View.GONE);
            }
        });
    }


    private void  internet(){
        water.setVisibility(View.GONE);
        electricity.setVisibility(View.GONE);
        internet.setVisibility(View.VISIBLE);
        search_biller.setVisibility(View.GONE);

        pay_zuku_internet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                internet.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title        = "Pay Zuku Internet";
                String account      = "Account number";
                String amount       = "amount";
                String screenToLoad = "zuku_internet";
                String bill_operator = "zuku_internet";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);
            }
        });

        payment_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mybill_account_number.setText("");
                mybill_amount.setText("");

                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                internet.setVisibility(View.VISIBLE);
                payment_layout.setVisibility(View.GONE);
            }
        });
    }

    private void airtime()
    {
        water.setVisibility(View.GONE);
        electricity.setVisibility(View.GONE);
        internet.setVisibility(View.GONE);
        tv.setVisibility(View.GONE);
        airtime_layout.setVisibility(View.VISIBLE);
        search_biller.setVisibility(View.GONE);

        //get phone number
        SharedPreff pref = new SharedPreff();
        Map prefferences = pref.getSharedPref(PayBillsActivity.this);

        String phone = String.valueOf(prefferences.get("wallet_id"));
        String name  = String.valueOf(prefferences.get("fname"));

        if(phone != "null")
        {
            contact_name.setText(name);
            contact_name.setVisibility(View.VISIBLE);
            buy_airtime.setText(FormValidation.removePhonePrefixKe(phone));
        }



        search_contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(PayBillsActivity.this, Manifest.permission.READ_CONTACTS)
                        != PackageManager.PERMISSION_GRANTED) {
                    checkPermissions();
                    return;
                }

                Intent intent= new Intent(Intent.ACTION_PICK,  ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(intent, PICK_CONTACT_BUY_AIRTIME);


            }
        });

        pay_airtime_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get data from form & validate
                String phone_airtime    = buy_airtime.getText().toString().trim();
                String amount_airtime   = buy_amount.getText().toString().trim();


                if (FormValidation.phoneValidationKe(phone_airtime) == false) {
                    buy_airtime.setError("Invalid Phone Number");
                    return;
                }

                if (FormValidation.amountValidationAirtime(amount_airtime) == false) {
                    buy_amount.setError("Minimum Amount is ksh 5");
                    return;
                }

                // get selected radio button from radioGroup
                int operatorId = PayBillsActivity.this.operator.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                operator_radio = (RadioButton) findViewById(operatorId);

                if (PayBillsActivity.this.operator.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(PayBillsActivity.this, "Specify operator", Toast.LENGTH_LONG).show();
                    return;
                }


                // get selected radio button from radioGroup
                int selectedId = airtimepayoptions.getCheckedRadioButtonId();

                //find the radiobutton by returned id
                radioButton = (RadioButton) findViewById(selectedId);

                if (radioButton.getText().equals("eLipa Wallet"))
                {
                    //call quick login
                    Intent i=new Intent(PayBillsActivity.this, QuickLoginActivity.class);
                    i.putExtra("screen", "airtime");
                    startActivity(i);
                    return;
                }
                else {
                    /**call a popup to enter phone number*/
                    String bill_operator = "airtime";
                    account_to_pay  = buy_airtime.getText().toString().trim();
                    amount_to_pay   = buy_amount.getText().toString().trim();
                    othersPayPopUp(bill_operator);
                }


            }
        });
    }


    private void tv()
    {
        water.setVisibility(View.GONE);
        electricity.setVisibility(View.GONE);
        internet.setVisibility(View.GONE);
        tv.setVisibility(View.VISIBLE);
        search_biller.setVisibility(View.VISIBLE);

        pay_dstv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                internet.setVisibility(View.GONE);
                tv.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title        = "Pay DStv bill";
                String account      = "Account number";
                String amount       = "amount";
                String screenToLoad = "dstv";
                String bill_operator = "dstv";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);
            }
        });

        pay_gotv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                internet.setVisibility(View.GONE);
                tv.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title        = "Pay GOtv bill";
                String account      = "Account number";
                String amount       = "amount";
                String screenToLoad = "gotv";
                String bill_operator = "gotv";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);
            }
        });

        pay_zukutv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                internet.setVisibility(View.GONE);
                tv.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title        = "Pay Zukutv bill";
                String account      = "Account number";
                String amount       = "amount";
                String screenToLoad = "zuku";
                String bill_operator = "zuku";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);
            }
        });

        pay_starttimetv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                internet.setVisibility(View.GONE);
                tv.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

                String title        = "Pay StartTimes bill";
                String account      = "Account number";
                String amount       = "amount";
                String screenToLoad = "startimes";
                String bill_operator = "startimes";
                paymentInterface(title, account, amount, screenToLoad, bill_operator);
            }
        });

        payment_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mybill_account_number.setText("");
                mybill_amount.setText("");

                water.setVisibility(View.GONE);
                electricity.setVisibility(View.GONE);
                internet.setVisibility(View.GONE);
                payment_layout.setVisibility(View.GONE);
                tv.setVisibility(View.VISIBLE);
            }
        });
    }

    private void sendMoney()
    {
        water.setVisibility(View.GONE);
        electricity.setVisibility(View.GONE);
        internet.setVisibility(View.GONE);
        tv.setVisibility(View.GONE);
        send_money_layout.setVisibility(View.VISIBLE);
        search_biller.setVisibility(View.GONE);

        sendmoney_search_contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(PayBillsActivity.this, Manifest.permission.READ_CONTACTS)
                        != PackageManager.PERMISSION_GRANTED) {
                    checkPermissions();
                    return;
                }

                Intent intent= new Intent(Intent.ACTION_PICK,  ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(intent, PICK_CONTACT_SEND_MONEY);

            }
        });

        sendmoney__button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get data from form & validate
                String phone_sendmoney    = sendmoney_number.getText().toString().trim();
                String amount_sendmoney   = sendmoney_amount.getText().toString().trim();

                if (FormValidation.phoneValidationKe(phone_sendmoney) == false) {
                    sendmoney_number.setError("Invalid Phone Number");
                    return;
                }

                if (FormValidation.amountValidation(amount_sendmoney) == false) {
                    sendmoney_amount.setError("Invalid amount");
                    return;
                }

                // get selected radio button from radioGroup
                int operatorId = PayBillsActivity.this.sendmoney.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                sendmoney_radio = (RadioButton) findViewById(operatorId);

                if (PayBillsActivity.this.sendmoney.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(PayBillsActivity.this, "Specify Channel", Toast.LENGTH_LONG).show();
                    return;
                }


                // get selected radio button from radioGroup
                int selectedId = sendmoney.getCheckedRadioButtonId();

                //find the radiobutton by returned id
                sendmoney_radio = (RadioButton) findViewById(selectedId);

                if (sendmoney_radio.getText().equals("eLipa Wallet")) {
                    //call quick login
                    Intent i = new Intent(PayBillsActivity.this, QuickLoginActivity.class);
                    i.putExtra("screen", "send_to_elipa_wallet");
                    startActivity(i);
                    return;
                }

                if (sendmoney_radio.getText().equals("mpesa")) {
                    //call quick login
                    Intent i = new Intent(PayBillsActivity.this, QuickLoginActivity.class);
                    i.putExtra("screen", "send_mobile_money");
                    startActivity(i);
                    return;
                }

                if (sendmoney_radio.getText().equals("airtel money")) {
                    //call quick login
                    Intent i = new Intent(PayBillsActivity.this, QuickLoginActivity.class);
                    i.putExtra("screen", "send_mobile_money");
                    startActivity(i);
                    return;
                }

                if (sendmoney_radio.getText().equals("Bank Account")) {
                   //popup here
                    SharedPreff pref = new SharedPreff();
                    Map prefferences = pref.getSharedPref(mContext);

                    String walletid     =  String.valueOf(prefferences.get("wallet_id"));
                    /**initiate sqlite*/
                    WalletDB db = new WalletDB(mContext);
                    JSONArray banks = db.getAllBanks(walletid);
                    if (banks.length() <= 0)
                    {
                        String msg = "No banks found! add a bank or sign-in to eLipa.";
                        String positive_button = "add bank";
                        String negative_button = "cancel";
                        subscribeDialog(msg, positive_button, negative_button);
                        return;
                    }
                    //call popup to display accounts
                    cachedBanksPopup(banks);


                    return;
                }

            }
        });

    }

    private void paymentInterface(final String title, final String account, final String amount, final String screenToLoad, final String bill_operator)
    {
        pay_title.setText(title);
        mybill_account_number.setHint(account);
        mybill_amount.setHint(amount);

        biller_list.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = ""+biller_list.getSelectedItem();
                text = text.substring(text.indexOf("(")+1);
                text = text.replace(")","");
                mybill_account_number.setText(""+text);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        pay_bill_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                account_to_pay = mybill_account_number.getText().toString().trim();
                amount_to_pay = mybill_amount.getText().toString().trim();

                if (FormValidation.accountValidation(account_to_pay) == false) {
                    mybill_account_number.setError("invalid Account number");
                    return;
                }

                if (FormValidation.amountValidation(amount_to_pay) == false) {
                    mybill_amount.setError("invalid amount");
                    return;
                }

                if (screenToLoad.toString().equals("pay_water"))
                {
                    if (FormValidation.amountValidationWater(amount_to_pay) == false) {
                        mybill_amount.setError("Minimum payment is ksh 200");
                        return;
                    }

                }

                if (screenToLoad.toString().equals("postpaid") ||
                        screenToLoad.toString().equals("prepaid"))
                {
                    if (FormValidation.amountValidationElectricity(amount_to_pay) == false) {
                        mybill_amount.setError("Minimum payment is ksh 200");
                        return;
                    }

                }

                if (screenToLoad.toString().equals("zuku_internet"))
                {
                    if (FormValidation.amountValidationZukuNet(amount_to_pay) == false) {
                        mybill_amount.setError("Minimum payment is ksh 500");
                        return;
                    }

                }

                if (screenToLoad.toString().equals("dstv") ||
                        screenToLoad.toString().equals("gotv") ||
                        screenToLoad.toString().equals("zuku") ||
                        screenToLoad.toString().equals("startimes"))
                {
                    if (FormValidation.amountValidationTv(amount_to_pay) == false) {
                        mybill_amount.setError("Minimum payment is ksh 500");
                        return;
                    }

                }

                // get selected radio button from radioGroup
                int selectedId = paymentOption.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioButton = (RadioButton) findViewById(selectedId);

                if (radioButton.getText().equals("eLipa Wallet"))
                {
                    //call quick login
                    Intent i=new Intent(PayBillsActivity.this, QuickLoginActivity.class);
                    i.putExtra("screen", screenToLoad);
                    startActivity(i);
                    return;
                }

                /**call a popup to enter phone number*/
                othersPayPopUp(bill_operator);

            }

        });


    }

    /**510800 popup **/
    private void othersPayPopUp(final String bill_operator){

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutpayotherpopup,null, false);

        final EditText others_phone_number    = (EditText) customView.findViewById(R.id.others_phone_number);
        Button others_action_button     = (Button) customView.findViewById(R.id.others_action_button);




        others_action_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String phones = others_phone_number.getText().toString().trim();
                final String emails = "support@elipa.co.ke";

                if (FormValidation.phoneValidationKe(phones) == false)
                {
                    Toast.makeText(mContext, "Invalid phone number", Toast.LENGTH_SHORT).show();
                    return;
                }

                CallIpay ipay = new CallIpay();
                ipay.callIpay(PayBillsActivity.this, amount_to_pay, phones , emails, bill_operator, account_to_pay);
            }
        });

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );


        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);
        mPopupWindow.showAtLocation(mLinearLayout, Gravity.CENTER,0,0);
    }

    /**user cached bank accounts popup */
    private void cachedBanksPopup(JSONArray banks) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutbankscachedpopup,null, false);

        ArrayList<Model> models;
        SendMoneyBankAdaptor mAdapter;

        ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

        /*** <----recycler code---- ***/
        RecyclerView bankscachedRecycler = (RecyclerView) customView.findViewById(R.id.banksCachedRecycler);

        bankscachedRecycler.setHasFixedSize(true);
        models = new ArrayList<>();
        mAdapter = new SendMoneyBankAdaptor(mContext, models);
        @SuppressLint("WrongConstant") LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        bankscachedRecycler.setLayoutManager(mLayoutManager);
        bankscachedRecycler.setItemAnimator(new DefaultItemAnimator());
        bankscachedRecycler.setAdapter(mAdapter);
        /*** ----recycler code />---- ***/

        /**extract json array from db */
        JSONArray jsonArray;
        jsonArray = banks;

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject object = null;
            Model data = new Model();
            try {
                object = (JSONObject) jsonArray.get(i);
                data.setBankName(object.getString("name"));
                data.setBankNickname(object.getString("nickname"));
                data.setBankPaybill(object.getString("paybill"));
                data.setBankAccountName(object.getString("accountname"));
                data.setBankAccountNumber(object.getString("accountnumber"));
                models.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        mAdapter.notifyDataSetChanged();

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the withdrawpopup window
                mPopupWindow.dismiss();
            }
        });

        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);
        mPopupWindow.showAtLocation(mLinearLayout, Gravity.CENTER,0,0);

    }


    public void paybillnow(final String biller_url, final String biller)
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(PayBillsActivity.this);
        mAuthProgressDialog.setMessage("processing please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(PayBillsActivity.this);

                //check wallet balance
                float balance = Float.valueOf((String) prefferences.get("wallet_balance"));
                String curr = String.valueOf(prefferences.get("curr"));
                String token = String.valueOf(prefferences.get("token"));

                if (balance < Integer.valueOf(amount_to_pay)) {
                    Toast.makeText(instance, "Insufficient funds!", Toast.LENGTH_LONG).show();
                    return;
                } else {

                    //form hashmap
                    Map<String, String> params = new HashMap<>();
                    params.put("account", account_to_pay);
                    params.put("amount", amount_to_pay);
                    params.put("currency", curr);
                    params.put("biller", biller);

                    HashMap<String, String> header = new HashMap<>();
                    header.put("Authorization", "Bearer " + token);

                    //send data to volley
                    String url = getString(R.string.baseUrl) +biller_url ;

                    VolleyStringRequest volley = new VolleyStringRequest();
                    volley.postData(PayBillsActivity.this, params, header, url, new VolleyCallBack() {
                        @Override
                        public void onSuccess(String result) {
                            //process results
                            JSONObject oprator = null;
                            try {

                                oprator = new JSONObject(result);

                                String header_status = oprator.getString("header_status");
                                String text = oprator.getString("text");

                                if (header_status.toString().trim().equals("200")) {

                                    mybill_account_number.setText("");
                                    mybill_amount.setText("");

                                    Toast.makeText(PayBillsActivity.this, ""+text, Toast.LENGTH_LONG).show();
                                }
                            }catch (JSONException e) {
                                e.printStackTrace();
                            }
                            //Toast.makeText(PayBillsActivity.this, "" + result, Toast.LENGTH_SHORT).show();

                        }
                    });
                }
            }
    }.start();
    }


    public void buyAirtimeNow()
    {
        final String phone_airtime    = buy_airtime.getText().toString().trim();
        final String amount_airtime   = buy_amount.getText().toString().trim();

        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(PayBillsActivity.this);
        mAuthProgressDialog.setMessage("processing please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(PayBillsActivity.this);

                //check wallet balance
                float balance = Float.valueOf((String) prefferences.get("wallet_balance"));
                String curr = String.valueOf(prefferences.get("curr"));
                String token = String.valueOf(prefferences.get("token"));

                if (balance < Integer.valueOf(amount_airtime)) {
                    Toast.makeText(instance, "Insufficient funds!", Toast.LENGTH_LONG).show();
                    return;
                } else {

                    //form hashmap
                    Map<String, String> params = new HashMap<>();
                    params.put("account", FormValidation.phonePrefixKe(phone_airtime));
                    params.put("amount", amount_airtime);
                    params.put("currency", curr);
                    params.put("biller", operator_radio.getText().toString().trim());

                    HashMap<String, String> header = new HashMap<>();
                    header.put("Authorization", "Bearer " + token);

                    //send data to volley
                    String url = getString(R.string.baseUrl) +"/wallet/billing/airtime" ;

                    VolleyStringRequest volley = new VolleyStringRequest();
                    volley.postData(PayBillsActivity.this, params, header, url, new VolleyCallBack() {
                        @Override
                        public void onSuccess(String result) {
                            JSONObject oprator = null;
                            try {

                                oprator = new JSONObject(result);

                                String header_status = oprator.getString("header_status");
                                String text = oprator.getString("text");

                                if (header_status.toString().trim().equals("200")) {

                                    buy_airtime.setText("");
                                    buy_amount.setText("");

                                    Toast.makeText(PayBillsActivity.this, ""+text, Toast.LENGTH_LONG).show();
                                }
                            }catch (JSONException e) {
                                e.printStackTrace();
                            }
                            //Toast.makeText(PayBillsActivity.this, "" + result, Toast.LENGTH_SHORT).show();

                        }
                    });
                }
            }
        }.start();
    }


    //send money now, only used by send money to elipa
    public void sendMoneyNow()
    {
        final String phone_sendmoney    = sendmoney_number.getText().toString().trim();
        final String amount_sendmoney   = sendmoney_amount.getText().toString().trim();

        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(PayBillsActivity.this);
        mAuthProgressDialog.setMessage("processing please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(PayBillsActivity.this);

                //check wallet balance
                float balance = Float.valueOf((String) prefferences.get("wallet_balance"));
                String curr = String.valueOf(prefferences.get("curr"));
                String token = String.valueOf(prefferences.get("token"));
                String phone_number = String.valueOf(prefferences.get("wallet_id"));

                if (FormValidation.phonePrefixKe(phone_number).equals(FormValidation.phonePrefixKe(phone_sendmoney)))
                {
                    Toast.makeText(instance, "You Cannot send money to yourself!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (balance < Integer.valueOf(amount_sendmoney)) {
                    Toast.makeText(instance, "Insufficient funds!", Toast.LENGTH_LONG).show();
                    return;
                } else {

                    //form hashmap
                    Map<String, String> params = new HashMap<>();
                    params.put("phone", FormValidation.phonePrefixKe(phone_sendmoney));
                    params.put("amount", amount_sendmoney);
                    params.put("currency", curr);

                    HashMap<String, String> header = new HashMap<>();
                    header.put("Authorization", "Bearer " + token);

                    //send data to volley
                    String url = getString(R.string.baseUrl) +"/wallet/sendmoney" ;

                    VolleyStringRequest volley = new VolleyStringRequest();
                    volley.postData(PayBillsActivity.this, params, header, url, new VolleyCallBack() {
                        @Override
                        public void onSuccess(String result) {
                            JSONObject oprator = null;
                            try {

                                oprator = new JSONObject(result);

                                String header_status = oprator.getString("header_status");
                                String text = oprator.getString("text");

                                if (header_status.toString().trim().equals("200")) {

                                    sendmoney_number.setText("");
                                    sendmoney_amount.setText("");

                                    Toast.makeText(PayBillsActivity.this, ""+text, Toast.LENGTH_LONG).show();
                                }
                            }catch (JSONException e) {
                                e.printStackTrace();
                            }
                            //Toast.makeText(PayBillsActivity.this, "" + result, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }.start();
    }

    /** process contacts response */
    @Override
    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);
        String phone = null;
        switch (reqCode) {
            case (PICK_CONTACT_BUY_AIRTIME) :
                if (resultCode == Activity.RESULT_OK) {
                    Uri contactData = data.getData();
                    Cursor c =  managedQuery(contactData, null, null, null, null);
                    if (c.moveToFirst()) {

                        String id =c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));

                        String hasPhone =c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

                        if (hasPhone.equalsIgnoreCase("1")) {
                            Cursor phones = getContentResolver().query(
                                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ id,
                                    null, null);
                            phones.moveToFirst();
                            phone = phones.getString(phones.getColumnIndex("data1"));
                            //System.out.println("number is:"+cNumber);
                        }

                        String name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));

                        buy_airtime.setText("");
                        contact_name.setText(name);
                        contact_name.setVisibility(View.VISIBLE);
                        buy_airtime.setText(FormValidation.removePhonePrefixKe(phone));
                        //Toast.makeText(instance, "name "+name+" phone " +phone, Toast.LENGTH_SHORT).show();

                    }
                }
                break;

            case (PICK_CONTACT_SEND_MONEY) :
                if (resultCode == Activity.RESULT_OK) {
                    Uri contactData = data.getData();
                    Cursor c =  managedQuery(contactData, null, null, null, null);
                    if (c.moveToFirst()) {

                        String id =c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));

                        String hasPhone =c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

                        if (hasPhone.equalsIgnoreCase("1")) {
                            Cursor phones = getContentResolver().query(
                                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ id,
                                    null, null);
                            phones.moveToFirst();
                            phone = phones.getString(phones.getColumnIndex("data1"));
                            //System.out.println("number is:"+cNumber);
                        }

                        String name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));

                        sendmoney_number.setText("");
                        sendmoney_contact_name.setText(name);
                        sendmoney_contact_name.setVisibility(View.VISIBLE);
                        sendmoney_number.setText(FormValidation.removePhonePrefixKe(phone));
                        //Toast.makeText(instance, "name "+name+" phone " +phone, Toast.LENGTH_SHORT).show();

                    }
                }
                break;
        }
    }


    /** request permission */
    protected void checkPermissions() {
        final List<String> missingPermissions = new ArrayList<String>();
        // check all required dynamic permissions
        for (final String permission : REQUIRED_SDK_PERMISSIONS) {
            final int result = ContextCompat.checkSelfPermission(this, permission);
            if (result != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }
        if (!missingPermissions.isEmpty()) {
            // request all missing permissions
            final String[] permissions = missingPermissions
                    .toArray(new String[missingPermissions.size()]);
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            final int[] grantResults = new int[REQUIRED_SDK_PERMISSIONS.length];
            Arrays.fill(grantResults, PackageManager.PERMISSION_GRANTED);
            onRequestPermissionsResult(REQUEST_CODE_ASK_PERMISSIONS, REQUIRED_SDK_PERMISSIONS,
                    grantResults);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                for (int index = permissions.length - 1; index >= 0; --index) {
                    if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {
                        // exit the app if one permission is not granted
                        Toast.makeText(this, "Required permission '" + permissions[index]
                                + "' not granted", Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                break;
        }
    }

    /** dialog */
    private void subscribeDialog(String msg, String positive_button, String negative_button)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(PayBillsActivity.this, R.style.AppCompatAlertDialogStyle);

        builder.setMessage(""+msg);

        builder.setPositiveButton(""+positive_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Intent i=new Intent(PayBillsActivity.this, QuickLoginActivity.class);
                i.putExtra("screen", " getBanks");
                startActivity(i);
                finish();
                return;
            }
        });

        builder.setNegativeButton(""+negative_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setCancelable(false);
        builder.show();
    }

}
