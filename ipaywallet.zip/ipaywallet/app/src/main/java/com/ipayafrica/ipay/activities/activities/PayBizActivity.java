package com.ipayafrica.ipay.activities.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.appcompat.widget.Toolbar;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.CallIpay;
import com.ipayafrica.ipay.activities.utils.FormValidation;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PayBizActivity extends AppCompatActivity {

    Button pay_biz_now;
    ImageView notification_back, notify_back;
    LinearLayout pay_biz_ipay, pay_biz_paybill, pay_biz_till, donate_to_kileleshwa,
            donate_to_deliverance, Donate_to_CITAM, Donate_to_AIC;
    CardView biz_options, pay_options, donation_options;
    TextView pay_title;
    Button go_to_mywallet, go_to_topup, go_to_withdrawal;
    EditText account_number, account_narration, amount;
    RadioGroup paymentOption;
    private RadioButton radioButton;
    String currentScreen, vendorId;

    String accnumber, narration, amounts;

    public PopupWindow mPopupWindow;
    private Context mContext;
    private LinearLayout mLinearLayout;

    static PayBizActivity instance;
    public static PayBizActivity getInstace(){
        if(instance == null){
            instance = new PayBizActivity ();
        }
        return instance;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_biz);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        instance = this;

        mLinearLayout = (LinearLayout) findViewById(R.id.mypaybiz);
        mContext = this;


        pay_title = (TextView) findViewById(R.id.pay_title);

        account_number      = (EditText) findViewById(R.id.account_number);
        account_narration   = (EditText) findViewById(R.id.account_narration);
        amount              = (EditText) findViewById(R.id.amount);

        notification_back = (ImageView) findViewById(R.id.notification_back);
        notify_back       = (ImageView) findViewById(R.id.notify_back);

        go_to_mywallet      = (Button) findViewById(R.id.mywallet);
        go_to_topup         = (Button) findViewById(R.id.topup);
        go_to_withdrawal    = (Button) findViewById(R.id.withdrawal);


        pay_biz_ipay            = (LinearLayout) findViewById(R.id.pay_biz_ipay);
        pay_biz_paybill         = (LinearLayout) findViewById(R.id.pay_biz_paybill);
        pay_biz_till            = (LinearLayout) findViewById(R.id.pay_biz_till);
        donate_to_kileleshwa    = (LinearLayout) findViewById(R.id.donate_to_kileleshwa);
        donate_to_deliverance   = (LinearLayout) findViewById(R.id.donate_to_deliverance);
        Donate_to_CITAM         = (LinearLayout) findViewById(R.id.Donate_to_CITAM);
        Donate_to_AIC           = (LinearLayout) findViewById(R.id.Donate_to_AIC);

        biz_options         = (CardView) findViewById(R.id.buz_options);
        donation_options    = (CardView) findViewById(R.id.donation_options);
        pay_options         = (CardView) findViewById(R.id.pay_options);

        pay_biz_now = (Button) findViewById(R.id.pay_biz_now);

        paymentOption = (RadioGroup) findViewById(R.id.paymentOption);


        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (biz_options.getVisibility() == View.VISIBLE ||
                        currentScreen.trim().equals("donate"))
                {
                    finish();
                }else {
                    biz_options.setVisibility(View.VISIBLE);
                }

            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (biz_options.getVisibility() == View.VISIBLE ||
                        currentScreen.trim().equals("donate"))
                {
                    finish();
                }else {
                    biz_options.setVisibility(View.VISIBLE);
                }
            }
        });

        /** call wallet activity */
        go_to_mywallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PayBizActivity.this, MyWalletActivity.class));
                finish();
            }
        });
        go_to_topup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PayBizActivity.this, MyWalletActivity.class));
                finish();
            }
        });
        go_to_withdrawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PayBizActivity.this, MyWalletActivity.class));
                finish();
            }
        });

        /** invoke methods here **/
        exchangeLayout();

    }

    @Override
    public void onBackPressed() {
        if (biz_options.getVisibility() == View.VISIBLE ||
                currentScreen.trim().equals("donate"))
        {
            finish();
        }else {
            biz_options.setVisibility(View.VISIBLE);
        }
    }

    /** control the different biz options (ipay, till, paybill) **/
    private void exchangeLayout()
    {
        pay_biz_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                accnumber = account_number.getText().toString().trim();
                narration = account_narration.getText().toString().trim();
                amounts = amount.getText().toString().trim();

                // get selected radio button from radioGroup
                int selectedId = paymentOption.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioButton = (RadioButton) findViewById(selectedId);


                if (FormValidation.accountValidation(accnumber) == false) {
                    account_number.setError("invalid biller number");
                    return;
                }

                if (FormValidation.narattionValidation(narration) == false) {
                    account_narration.setError("invalid narration/account");
                    return;
                }

                if (FormValidation.amountValidation(amounts) == false) {
                    amount.setError("invalid amount");
                    return;
                }


                if (radioButton.getText().equals("eLipa Wallet"))
                {
                    Intent i=new Intent(PayBizActivity.this, QuickLoginActivity.class);
                    i.putExtra("screen", "pay_business");
                    startActivity(i);
                    return;
                }

                /**call a popup to enter phone number*/
                String bill_operator = "pay_business";
                othersPayPopUp(bill_operator, amounts, accnumber, narration);
            }
        });

        /** get screen to load */
        //get extra
        Intent intent = getIntent();
        if (intent != null) {
            currentScreen = intent.getStringExtra("screen");
            if (currentScreen.trim().equals("donate")) {
                biz_options.setVisibility(View.GONE);
                donation_options.setVisibility(View.VISIBLE);
                /** load donation vendors */
                donate_to_kileleshwa.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        biz_options.setVisibility(View.GONE);
                        donation_options.setVisibility(View.GONE);
                        pay_options.setVisibility(View.VISIBLE);
                        pay_title.setText("Make your Donation To");
                        account_number.setHint("Kileleshwa");
                        account_number.setEnabled(false);
                        account_number.setTextColor(getResources().getColor(R.color.colorBlack));
                        account_number.setText(getString(R.string.description_k3c));
                        vendorId = "k3c";
                        account_narration.setVisibility(View.GONE);
                        account_narration.setText("elipa Merchant");
                        amount.setHint("Amount");
                    }
                });

                donate_to_deliverance.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        biz_options.setVisibility(View.GONE);
                        donation_options.setVisibility(View.GONE);
                        pay_options.setVisibility(View.VISIBLE);
                        pay_title.setText("Make Your Donation To");
                        account_number.setHint("Delivarance");
                        account_number.setEnabled(false);
                        account_number.setTextColor(getResources().getColor(R.color.colorBlack));
                        account_number.setText(getString(R.string.description_deliverance));
                        vendorId = "sr";
                        account_narration.setVisibility(View.GONE);
                        account_narration.setText("elipa Merchant");
                        amount.setHint("Amount");
                    }
                });

                Donate_to_CITAM.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        biz_options.setVisibility(View.GONE);
                        donation_options.setVisibility(View.GONE);
                        pay_options.setVisibility(View.VISIBLE);
                        pay_title.setText("Make Your Donation To");
                        account_number.setHint("CITAM");
                        account_number.setEnabled(false);
                        account_number.setTextColor(getResources().getColor(R.color.colorBlack));
                        account_number.setText(getString(R.string.description_citam));
                        vendorId = "8000";
                        account_narration.setVisibility(View.GONE);
                        account_narration.setText("elipa Merchant");
                        amount.setHint("Amount");
                    }
                });

                Donate_to_AIC.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        biz_options.setVisibility(View.GONE);
                        donation_options.setVisibility(View.GONE);
                        pay_options.setVisibility(View.VISIBLE);
                        pay_title.setText("Make Your Donation To");
                        account_number.setHint("AIC");
                        account_number.setEnabled(false);
                        account_number.setTextColor(getResources().getColor(R.color.colorBlack));
                        account_number.setText(getString(R.string.description_aic));
                        vendorId = "aiclgt";
                        account_narration.setVisibility(View.GONE);
                        account_narration.setText("elipa Merchant");
                        amount.setHint("Amount");
                    }
                });
                return;
            }
        }

        pay_biz_ipay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                biz_options.setVisibility(View.GONE);
                donation_options.setVisibility(View.GONE);
                pay_options.setVisibility(View.VISIBLE);
                pay_title.setText("Pay To Ipay Merchant");
                account_number.setHint("Vendor Id");
                account_number.setEnabled(true);
                account_narration.setVisibility(View.GONE);
                account_narration.setText("elipa Merchant");
                amount.setHint("Amount");

            }
        });

        pay_biz_paybill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                biz_options.setVisibility(View.GONE);
                donation_options.setVisibility(View.GONE);
                pay_options.setVisibility(View.VISIBLE);
                pay_title.setText("Pay To PayBill");
                account_number.setHint("PayBill Number");
                account_number.setEnabled(true);
                account_narration.setVisibility(View.VISIBLE);
                account_narration.setText("");
                account_narration.setHint("account");
                amount.setHint("Amount");

            }
        });

        pay_biz_till.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                biz_options.setVisibility(View.GONE);
                donation_options.setVisibility(View.GONE);
                pay_options.setVisibility(View.VISIBLE);
                pay_title.setText("Pay To Till");
                account_number.setHint("Till Number");
                account_number.setEnabled(true);
                account_narration.setVisibility(View.GONE);
                account_narration.setText("elipa till");
                amount.setHint("Amount");

            }
        });
    }

    public void copletePayment()
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(PayBizActivity.this);
        mAuthProgressDialog.setMessage("processing please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(PayBizActivity.this);

                //check wallet balance
                float balance   =  Float.valueOf((String) prefferences.get("wallet_balance"));
                String curr     =  String.valueOf(prefferences.get("curr"));
                String token    =  String.valueOf(prefferences.get("token"));


                if (balance < Integer.valueOf(amounts))
                {
                    Toast.makeText(instance, "Insufficient funds!", Toast.LENGTH_LONG).show();
                    return;
                }else {
                    //form hashmap
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("amount", amounts);
                    params.put("merchant", accnumber);
                    params.put("narration", narration);
                    params.put("currency", curr);

                    HashMap<String, String> header = new HashMap<String, String>();
                    header.put("Authorization", "Bearer " + token);

                    //send data to volley
                    String url = getString(R.string.baseUrl)+"merchant/pay";

                    VolleyStringRequest volley = new VolleyStringRequest();
                    volley.postData(PayBizActivity.this, params, header, url, new VolleyCallBack() {
                        @Override
                        public void onSuccess(String result) {
                           //process results
                            JSONObject oprator = null;
                            try {

                                oprator = new JSONObject(result);

                                String header_status = oprator.getString("header_status");
                                String text = oprator.getString("text");

                                if (header_status.toString().trim().equals("200")) {

                                    account_number.setText("");
                                    account_narration.setText("");
                                    amount.setText("");

                                    Toast.makeText(PayBizActivity.this, ""+text, Toast.LENGTH_LONG).show();
                                }
                            }catch (JSONException e) {
                                    e.printStackTrace();
                            }
                        }
                        });
                }
            }
        }.start();

    }

    /**510800 popup **/
    private void othersPayPopUp(final String bill_operator, final String amount_to_pay, final String account_to_pay, String narration){

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutpayotherpopup,null, false);

        final EditText others_phone_number    = (EditText) customView.findViewById(R.id.others_phone_number);
        Button others_action_button     = (Button) customView.findViewById(R.id.others_action_button);




        others_action_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String phones = others_phone_number.getText().toString().trim();
                final String emails = "support@elipa.co.ke";

                if (FormValidation.phoneValidationKe(phones) == false)
                {
                    Toast.makeText(mContext, "Invalid phone number", Toast.LENGTH_SHORT).show();
                    return;
                }

                CallIpay ipay = new CallIpay();
                ipay.callIpay(PayBizActivity.this, amount_to_pay, phones , emails, bill_operator, account_to_pay);
            }
        });

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );


        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);
        mPopupWindow.showAtLocation(mLinearLayout, Gravity.CENTER,0,0);
    }

}
