package com.ipayafrica.ipay.activities.activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    ImageView notification_back, notify_back;
    LinearLayout profile_data, profile_edit, password_fields;
    Button profile_changing_password, profile_editing, profile_change_password, profile_update;
    TextView profile_name, phone, email, id_number, dob, gender, balance, referral;
    EditText profile_edit_fname, profile_edit_lname, profile_edit_email, profile_edit_newpassword,
            profile_edit_confrimpassword;
    Map prefferences;
    /** params to send to db */
    String save_fname, save_lname, save_email, save_gender, save_password, save_confirm_password;
    private boolean isPasswordReset = false;

    static ProfileActivity instance;
    public static ProfileActivity getInstace(){
        if(instance == null){
            instance = new ProfileActivity ();
        }
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        instance = this;

        notification_back = (ImageView) findViewById(R.id.notification_back);
        notify_back       = (ImageView) findViewById(R.id.notify_back);

        profile_name = (TextView) findViewById(R.id.profile_name);
        phone = (TextView) findViewById(R.id.phone);
        email = (TextView) findViewById(R.id.email);
        id_number = (TextView) findViewById(R.id.id_number);
        dob = (TextView) findViewById(R.id.dob);
        gender = (TextView) findViewById(R.id.gender);
        balance = (TextView) findViewById(R.id.balance);
        referral = (TextView) findViewById(R.id.referral);

        profile_edit_fname              = (EditText) findViewById(R.id.profile_edit_fname);
        profile_edit_lname              = (EditText) findViewById(R.id.profile_edit_lname);
        profile_edit_email              = (EditText) findViewById(R.id.profile_edit_email);
        profile_edit_newpassword        = (EditText) findViewById(R.id.profile_edit_newpassword);
        profile_edit_confrimpassword    = (EditText) findViewById(R.id.profile_edit_confrimpassword);

        profile_changing_password   = (Button) findViewById(R.id.profile_changing_password);
        profile_editing             = (Button) findViewById(R.id.profile_editing);
        profile_change_password     = (Button) findViewById(R.id.profile_change_password);
        profile_update              = (Button) findViewById(R.id.profile_update);

        profile_data = (LinearLayout) findViewById(R.id.profile_data);
        profile_edit = (LinearLayout) findViewById(R.id.profile_edit);
        password_fields = (LinearLayout) findViewById(R.id.password_fields);


        /** back buttons */
        notification_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        notify_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //get Shared pref
        SharedPreff pref = new SharedPreff();
        prefferences = pref.getSharedPref(ProfileActivity.this);

        if (!prefferences.get(getString(R.string.wallet_wallet_id)).equals("null"))
        {
            profile_name.setText(""+prefferences.get(getString(R.string.wallet_fname))+" "+prefferences.get(getString(R.string.wallet_lname)));
            phone.setText(""+prefferences.get(getString(R.string.wallet_wallet_id)) );
            email.setText(""+prefferences.get(getString(R.string.wallet_email)) );
            id_number.setText(getString(R.string.quick_login_NA));
            dob.setText(getString(R.string.quick_login_NA));
            if (prefferences.get(getString(R.string.quick_login_gender)).equals(getString(R.string.quick_login_m)))
            {
                gender.setText(getString(R.string.quick_login_male));
            }else {
                gender.setText(getString(R.string.quick_login_female));
            }
            balance.setText(""+prefferences.get(getString(R.string.wallet_curr))+" "+prefferences.get(getString(R.string.wallet_balance)) );
            referral.setText(""+prefferences.get(getString(R.string.quick_login_referral_code)));
            profile_edit_fname.setHint(getString(R.string.quick_login_edit)+" "+prefferences.get(getString(R.string.wallet_fname)));
            if (!prefferences.get(getString(R.string.wallet_email)).equals(getString(R.string.quick_login_false))) profile_edit_email.setHint(getString(R.string.quick_login_edit)+" "+prefferences.get(getString(R.string.wallet_email)));

        }else {

            Intent i=new Intent(ProfileActivity.this, LoginActivity.class);
            i.putExtra(getString(R.string.wallet_screen), getString(R.string.quick_login_profile));
            startActivity(i);
            finish();
        }


        /** edit profile */
        profile_editing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profile_data.setVisibility(View.GONE);
                profile_edit.setVisibility(View.VISIBLE);
            }
        });
        profile_changing_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profile_data.setVisibility(View.GONE);
                profile_edit.setVisibility(View.VISIBLE);
                profile_change_password.setVisibility(View.GONE);
                password_fields.setVisibility(View.VISIBLE);
            }
        });
        profile_change_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                profile_change_password.setVisibility(View.GONE);
                password_fields.setVisibility(View.VISIBLE);
            }
        });

        /** save profile update */
        profile_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save_fname            = profile_edit_fname.getText().toString().trim();
                save_lname            = profile_edit_lname.getText().toString().trim();
                save_email            = profile_edit_email.getText().toString().trim();
                save_gender           = profile_edit_email.getText().toString().trim();
                save_password         = profile_edit_newpassword.getText().toString().trim();
                save_confirm_password = profile_edit_confrimpassword.getText().toString().trim();

                if (save_fname.equals("") &&
                        save_lname.equals("") &&
                        save_email.equals("") &&
                        save_password.equals("") &&
                        save_confirm_password.equals(""))
                {
                    Toast.makeText(ProfileActivity.this, getString(R.string.quick_login_nothing), Toast.LENGTH_LONG).show();
                    return;
                }

                if (save_fname.equals("")){
                    save_fname = ""+prefferences.get(getString(R.string.wallet_fname));
                }
                if (save_lname.equals("")){
                    save_lname = ""+prefferences.get(getString(R.string.wallet_lname));
                }
                if (save_email.equals("")){
                    save_email = ""+prefferences.get(getString(R.string.wallet_email));
                }
                if (save_gender.equals("")){
                    save_gender = ""+prefferences.get(getString(R.string.quick_login_gender));
                }

                if (!save_password.equals(save_confirm_password))
                {
                    Toast.makeText(ProfileActivity.this, getString(R.string.quick_login_password), Toast.LENGTH_LONG).show();
                    return;
                }

                if (!save_password.equals("") && save_password.length() < 4){
                    Toast.makeText(ProfileActivity.this, getString(R.string.quick_login_password_weak), Toast.LENGTH_SHORT).show();
                    return;
                }else {
                    isPasswordReset = true;
                }


                //call quick login
                Intent i=new Intent(ProfileActivity.this, QuickLoginActivity.class);
                i.putExtra(getString(R.string.wallet_screen), getString(R.string.quick_login_update));
                startActivity(i);
                return;
            }
        });

    }


    public void saveUpdates()
    {
        /*start loader for a second*/
        final ProgressDialog mAuthProgressDialog;
        mAuthProgressDialog = new ProgressDialog(ProfileActivity.this);
        mAuthProgressDialog.setMessage(getString(R.string.wallet_processing));
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        new CountDownTimer(2000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
                mAuthProgressDialog.cancel();

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(ProfileActivity.this);

                String token = String.valueOf(prefferences.get(getString(R.string.wallet_token)));

                    //form hashmap
                    Map<String, String> parameters = new HashMap<>();
                    parameters.put(getString(R.string.wallet_fname), save_fname);
                    parameters.put(getString(R.string.wallet_lname), save_lname);
                    parameters.put(getString(R.string.wallet_email), save_email);
                    parameters.put(getString(R.string.quick_login_gender), save_gender);
                    if (isPasswordReset) {
                        parameters.put(getString(R.string.quick_login_password_key), save_password);
                        parameters.put(getString(R.string.quick_login_password_confirm), save_confirm_password);
                    }

                    HashMap<String, String> header = new HashMap<>();
                    header.put(getString(R.string.biller_key_authorization), getString(R.string.my_bearer)+" " + token);

                    //send data to volley
                    String url = getString(R.string.baseUrl) +getString(R.string.quick_login_api_account);

                    VolleyStringRequest volley = new VolleyStringRequest();
                    volley.postData(ProfileActivity.this, parameters, header, url, new VolleyCallBack() {
                        @Override
                        public void onSuccess(String result) {

                            JSONObject oprator = null;
                            JSONObject account = null;
                            try {

                                oprator = new JSONObject(result);

                                String header_status = oprator.getString(getString(R.string.home_header_status_value));

                                if (header_status.toString().trim().equals(getString(R.string.home_header_status_200))) {
                                    String text = oprator.getString(getString(R.string.quick_login_text));
                                    String msg = text + getString(R.string.quick_login_sync);
                                    createDialog(msg);
                                }
                            }catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });

            }
        }.start();

    }


    //dialog popup
    private void createDialog(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this, R.style.AppCompatAlertDialogStyle);
        builder.setCancelable(false);
        builder.setMessage(""+msg);

        builder.setPositiveButton(getString(R.string.quick_login_sync_now), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                //call quick login
                Intent i=new Intent(ProfileActivity.this, LoginActivity.class);
                i.putExtra(getString(R.string.wallet_screen), getString(R.string.quick_login_profile));
                startActivity(i);
                finish();
            }
        });

        builder.show();

    }

}
