package com.ipayafrica.ipay.activities.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.FormValidation;
import com.ipayafrica.ipay.activities.utils.Model;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.adapters.AccountsAdator;
import com.ipayafrica.ipay.activities.utils.database.WalletDB;
import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class QuickLoginActivity extends AppCompatActivity {

    Button quick_cancel, quick_continue, show_acc;
    TextView quick_username, quick_phone;
    EditText quick_password;

    String nextscreen;
    WalletDB db;

    public PopupWindow mPopupWindow;
    private Context mContext;
    private RelativeLayout mRelativeLayout;

    static QuickLoginActivity instance;
    public static QuickLoginActivity getInstace(){
        if(instance == null){
            instance = new QuickLoginActivity ();
        }
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quick_login);

        instance = this;

        /**initiate sqlite*/
        db = new WalletDB(QuickLoginActivity.this);

        mContext= this;
        mRelativeLayout=(RelativeLayout) findViewById(R.id.account_home);

        quick_cancel    = (Button) findViewById(R.id.quick_cancel);
        quick_continue  = (Button) findViewById(R.id.quick_continue);
        show_acc        = (Button) findViewById(R.id.show_acc);

        quick_username  = (TextView) findViewById(R.id.quick_username);
        quick_phone     = (TextView) findViewById(R.id.quick_phone);

        quick_password  = (EditText) findViewById(R.id.quick_password);

        quick_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        quick_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = getIntent();
                if (intent != null) {
                    nextscreen = intent.getStringExtra(getString(R.string.wallet_screen));
                }

                //form hashmap
                Map<String, String> params = new HashMap<>();
                params.put(getString(R.string.pass_phone), FormValidation.phonePrefixKe(quick_phone.getText().toString().trim()));
                params.put(getString(R.string.pass_password), quick_password.getText().toString().trim());
                params.put(getString(R.string.pass_f_token), FirebaseInstanceId.getInstance().getToken());
                params.put(getString(R.string.pass_device), getString(R.string.the_device));

                HashMap<String, String> header = new HashMap<>();
                header.put(getString(R.string.pass_Authorization), getString(R.string.pass_Bearer)+" ");

                //send data to volley
                String url = getString(R.string.baseUrl)+getString(R.string.login_api_authorization);

                VolleyStringRequest volley = new VolleyStringRequest();
                volley.postDataLogin(QuickLoginActivity.this, params, header, url, new VolleyCallBack() {
                    @Override
                    public void onSuccess(String result) {
                        //send results to shared-pref
                        SharedPreff pref = new SharedPreff();
                        pref.sharedPreffLogin(QuickLoginActivity.this, result, nextscreen);

                    }
                });

            }
        });

        /**get all accounts */
        show_acc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /** get user data **/
                JSONArray user = db.getAllUser();
                if (user.length() >= 1)
                {
                    //call popup to display accounts
                    accountPopup(user);
                }
            }
        });


        getSharedPreff();
    }

    /**user account popup */
    private void accountPopup(JSONArray user)
    {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        // Inflate the custom view
        View customView = inflater.inflate(R.layout.layoutaccountpopup,null, false);

        ArrayList<Model> models;
        AccountsAdator mAdapter;


        /*** <----recycler code---- ***/
        RecyclerView accountsrecycler = (RecyclerView) customView.findViewById(R.id.accountsrecycler);

        accountsrecycler.setHasFixedSize(true);
        models = new ArrayList<>();
        mAdapter = new AccountsAdator(mContext, models);
        @SuppressLint("WrongConstant") LinearLayoutManager mLayoutManager
                = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        accountsrecycler.setLayoutManager(mLayoutManager);
        accountsrecycler.setItemAnimator(new DefaultItemAnimator());
        accountsrecycler.setAdapter(mAdapter);
        /*** ----recycler code />---- ***/

        /**extract json array from db */
        JSONArray jsonArray;
        jsonArray = user;

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject object = null;
            Model data = new Model();
            try {
                object = (JSONObject) jsonArray.get(i);
                data.setAccountId(object.getString(getString(R.string.quick_login_id)));
                data.setAccountName(object.getString(getString(R.string.quick_login_name)));
                data.setAccountWalletId(object.getString(getString(R.string.quick_login_phone)));
                models.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        mAdapter.notifyDataSetChanged();

        mPopupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }
        mPopupWindow.isFocusable();
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(false);
        mPopupWindow.showAtLocation(mRelativeLayout, Gravity.CENTER,0,0);
    }

    /** choose another account */
    public void anotherAccount(String name, String phone)
    {
        quick_username.setText(getString(R.string.quick_login_hello)+" "+name);
        quick_phone.setText(""+phone);
        mPopupWindow.dismiss();
    }

    /**delete account*/
    public void deleteUser(String phone)
    {
        String walletId = FormValidation.phonePrefixKe(phone);
        db.deleteUser(walletId);
        mPopupWindow.dismiss();
        Toast.makeText(mContext, getString(R.string.quick_login_account)+" "+walletId+getString(R.string.quick_login_deleted)+" ", Toast.LENGTH_SHORT).show();
        //get Shared pref and logout if account is deleted
        SharedPreff pref = new SharedPreff();
        Map prefferences = pref.getSharedPref(QuickLoginActivity.this);
        if (prefferences.get(getString(R.string.wallet_wallet_id)).equals(walletId))
        {
            SharedPreff preff = new SharedPreff();
            preff.clearSharedPref(QuickLoginActivity.this);
            finish();
        }

    }

    //get shared preff
    private void getSharedPreff()
    {
        //get Shared pref
        SharedPreff pref = new SharedPreff();
        Map prefferences = pref.getSharedPref(QuickLoginActivity.this);


        if (!prefferences.get(getString(R.string.wallet_wallet_id)).equals("null"))
        {
            quick_username.setText(getString(R.string.quick_login_hello)+" "+prefferences.get(getString(R.string.wallet_fname)));
            quick_phone.setText(""+prefferences.get(getString(R.string.wallet_wallet_id)) );
        }else {

            Intent i= getIntent();
            Bundle screen = i.getExtras();
            if(screen!=null)
            {
                nextscreen =(String) screen.get(getString(R.string.wallet_screen));
            }

            Intent intent=new Intent(QuickLoginActivity.this, LoginActivity.class);
            intent.putExtra(getString(R.string.wallet_screen), nextscreen);
            startActivity(intent);

            //startActivity(new Intent(QuickLoginActivity.this, LoginActivity.class));
            finish();
        }
    }

}
