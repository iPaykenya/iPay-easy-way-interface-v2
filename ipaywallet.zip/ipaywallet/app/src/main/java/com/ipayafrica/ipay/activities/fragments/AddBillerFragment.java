//package com.ipayafrica.ipay.activities.fragments;
//
//import android.app.ProgressDialog;
//import android.content.Context;
//import android.content.Intent;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Bundle;
//import android.os.CountDownTimer;
//import android.support.v4.app.Fragment;
//import android.view.Gravity;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.PopupWindow;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.ipayafrica.ipay.R;
//import com.ipayafrica.ipay.activities.activities.BillersActivity;
//import com.ipayafrica.ipay.activities.activities.PayBillsActivity;
//import com.ipayafrica.ipay.activities.activities.ProfileActivity;
//import com.ipayafrica.ipay.activities.activities.QuickLoginActivity;
//import com.ipayafrica.ipay.activities.utils.FormValidation;
//import com.ipayafrica.ipay.activities.utils.SharedPreff;
//import com.ipayafrica.ipay.activities.utils.volley.VolleyCallBack;
//import com.ipayafrica.ipay.activities.utils.volley.VolleyStringRequest;
//
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import static android.content.Context.LAYOUT_INFLATER_SERVICE;
//
//
//public class AddBillerFragment extends Fragment {
//
//
//
//    public AddBillerFragment() {
//        // Required empty public constructor
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        View view = inflater.inflate(R.layout.fragment_add_biller, container, false);
//
//        return view;
//    }
//
//
//
//
//
//}
