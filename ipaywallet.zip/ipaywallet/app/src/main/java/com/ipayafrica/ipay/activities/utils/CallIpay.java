package com.ipayafrica.ipay.activities.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.ipay.iPaycheckout.PaymentActivity;

/**
 * processes 510800
 */
public class CallIpay {

    public void callIpay(Context context, String amounts, String phones, String emails, String operator, String account)
    {

        String my_vid = null, vid_key = null, me = null;
        ApplicationInfo ai = null;
        try {
            ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            my_vid = bundle.getString("vid");
            vid_key = bundle.getString("vid_key");
            me = bundle.getString("me");
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        //data to send to ipay
        String live             = "1";
        String oid              = "";
        String mer              = me; //merchant name
        String amount           = amounts;//amounts;
        String phone_number     = phones;
        String email            = emails;
        String vid              = my_vid;  //TODO get Vendor ID from lucy
        String curr             = "KES"; //or USD
        String cst              = "1"; //email notification
        String crl              = "0";
        String autopay          = "1";
        String cbk              = "https://www.google.com"; //TODO callback url
        String security_key     = vid_key; //TODO get key from lucy
        /** can pass extra param below **/
        String p1               = operator;
        String p2               = account;
        String p3               = "";
        String p4               = "";

        /**channel setting (1-sets on && 0-sets off)**/
        String mpesa_status    = "1";
        String mbonga_status   = "1";
        String airtel_status   = "1";
        String easy_status     = "1";
        String visa_status     = "1";


        Intent data = new Intent(context, PaymentActivity.class);
        data.putExtra("live", live);
        data.putExtra("mer", mer);
        data.putExtra("oid", oid);
        data.putExtra("vid", vid);
        data.putExtra("cbk", cbk);
        data.putExtra("key", security_key);
        data.putExtra("amount", amount);
        data.putExtra("autopay", autopay);
        data.putExtra("p1", p1);
        data.putExtra("p2", p2);
        data.putExtra("p3", p3);
        data.putExtra("p4", p4);
        data.putExtra("currency", curr);
        data.putExtra("cst", cst);
        data.putExtra("crl", crl);
        data.putExtra("phone", phone_number);
        data.putExtra("email", email);
        data.putExtra("mpesa_status", mpesa_status);
        data.putExtra("mbonga_status", mbonga_status);
        data.putExtra("airtel_status", airtel_status);
        data.putExtra("easy_status", easy_status);
        data.putExtra("visa_status", visa_status);
        context.startActivity(data);
        ((Activity) context).finish();
    }

}
