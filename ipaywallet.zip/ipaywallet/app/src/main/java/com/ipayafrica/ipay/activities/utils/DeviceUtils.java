package com.ipayafrica.ipay.activities.utils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.safetynet.SafetyNet;
import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.activities.HomeActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.SecureRandom;

public class DeviceUtils {

    public void ifGooglePlayServicesValid(Context context) {


        String my_google = null;
        ApplicationInfo ai = null;
        try {
            ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            my_google = bundle.getString("my_google");
        } catch (PackageManager.NameNotFoundException e) {
            //e.printStackTrace();
            showAlertDialogOpenPlayStore(context.getString(R.string.unsuported_play_store), context);
        }

        if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context)
                == ConnectionResult.SUCCESS) {
            // The SafetyNet Attestation API is available.
            callSafetyNetAttentationApi(context, my_google);

        } else {
            // Prompt user to update Google Play services.
            HomeActivity.getInstace().mAuthProgressDialog.dismiss();
            showAlertDialogOpenPlayStore(context.getString(R.string.unsuported_play_store), context);
        }
    }

    private void callSafetyNetAttentationApi(Context context, String my_google) {
        SafetyNet.getClient(context).attest(generateNonce(), my_google)
                .addOnSuccessListener((Activity) context,
                        response -> {
                            // Use response.getJwsResult() to get the result data.
                            String jwsResponse = decodeJws(response.getJwsResult());
                            HomeActivity.getInstace().mAuthProgressDialog.dismiss();
                            try {
                                JSONObject attestationResponse = new JSONObject(jwsResponse);
                                boolean ctsProfileMatch = attestationResponse.getBoolean("ctsProfileMatch");
                                boolean basicIntegrity = attestationResponse.getBoolean("basicIntegrity");
                                if (!ctsProfileMatch || !basicIntegrity) {
                                    // this indicates it's rooted/tampered device
                                    showAlertDialogAndExitApp(context.getString(R.string.unsuported_app),  context);
                                }
                            } catch (JSONException e) {
                                // json exception
                                //Toast.makeText(context, "error occurred", Toast.LENGTH_SHORT).show();
                            }
                        })
                .addOnFailureListener((Activity) context, e -> {
                    // An error occurred while communicating with the service.
                    //Toast.makeText(context, "key error occurred", Toast.LENGTH_SHORT).show();
                });
    }

    public String decodeJws(String jwsResult) {
        if (jwsResult == null) {
            return null;
        }
        final String[] jwtParts = jwsResult.split("\\.");
        if (jwtParts.length == 3) {
            return new String(Base64.decode(jwtParts[1], Base64.DEFAULT));
        } else {
            return null;
        }
    }

    private byte[] generateNonce() {
        byte[] nonce = new byte[16];
        new SecureRandom().nextBytes(nonce);
        return nonce;
    }

    public void showAlertDialogAndExitApp(String msg, Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AppCompatAlertDialogStyle);

        builder.setMessage(""+msg);

        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Intent intent = new Intent(Intent.ACTION_DELETE);
                intent.setData(Uri.parse("package:com.ipayafrica.ipay"));
                context.startActivity(intent);
                ((Activity)context).finish();
                return;
            }
        });

        builder.setCancelable(false);
        builder.show();
    }

    public void showAlertDialogOpenPlayStore(String msg, Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AppCompatAlertDialogStyle);

        builder.setMessage(""+msg);

        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                try {
                    Uri marketUri = Uri.parse("market://details?id=");
                    Intent myIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                    myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(myIntent);
                }catch (ActivityNotFoundException e){
                }
                ((Activity)context).finish();
                return;
            }
        });

        builder.setCancelable(false);
        builder.show();
    }


    public boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

//    public Boolean isDeviceRooted(Context context){
//        boolean isRooted = isrooted1() || isrooted2();
//        return isRooted;
//    }
//
//    private boolean isrooted1() {
//
//        File file = new File("/system/app/Superuser.apk");
//        if (file.exists()) {
//            return true;
//        }
//        return false;
//    }
//
//    // try executing commands
//    private boolean isrooted2() {
//        return canExecuteCommand("/system/xbin/which su");
//    }
//
//
//    private static boolean canExecuteCommand(String command) {
//        boolean executedSuccesfully;
//        try {
//            Runtime.getRuntime().exec(command);
//            executedSuccesfully = true;
//        } catch (Exception e) {
//            executedSuccesfully = false;
//        }
//
//        return executedSuccesfully;
//    }


}
