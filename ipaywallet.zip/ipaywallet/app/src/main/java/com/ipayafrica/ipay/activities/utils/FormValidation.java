package com.ipayafrica.ipay.activities.utils;

import android.widget.Toast;

public class FormValidation {

    //validate Ke phone number only
    public static boolean phoneValidationKe(String Phone)
    {

        if(Phone.equals("") ||
                Phone.length() != 10 ||
                !Phone.substring(0,2).toString().equals("07"))
            return false;

        else return true;

    }

    //add prefix to valid Ke phone number
    public static String phonePrefixKe(String phone)
    {
        String start_char = phone.substring(0,2);

        String tel = phone;
        
        if (start_char.toString().trim().equals("07")) {
            String last_chars = phone.substring(1, 10);
            tel = "254" + last_chars;
        }
        return tel;
    }

    //add prefix to valid Ke phone number
    public static String removePhonePrefixKe(String phone)
    {
        //remove special characters
        phone = phone.replaceAll("[\\D]", "");

        String start_char = phone.substring(0,3);

        String tel = phone;

        if (start_char.toString().trim().equals("254")) {
            String last_chars = phone.substring(3, 12);
            tel = "0" + last_chars;
        }

        return tel;
    }

    public static boolean passwordValidation(String password)
    {
        if(password.equals("")) return false;

        else return true;
    }

    public static boolean accountValidation(String accounts)
    {
        if(accounts.equals("")) return false;

        else return true;
    }

    public static boolean narattionValidation(String acc_number)
    {
        if(acc_number.equals("")) return false;

        else return true;
    }

    public static boolean amountValidation(String amount)
    {
        if (amount.equals("") || Integer.valueOf(amount) <= 0)
            return false;

        else
            return true;

    }

    public static boolean amountValidationAirtime(String amount)
    {
        if (amount.equals("") || Integer.valueOf(amount) < 5)
            return false;

        else
            return true;

    }

    public static boolean amountValidationWater(String amount)
    {
        if (amount.equals("") || Integer.valueOf(amount) < 200)
            return false;

        else
            return true;

    }


    public static boolean amountValidationElectricity(String amount)
    {
        if (amount.equals("") || Integer.valueOf(amount) < 200)
            return false;

        else
            return true;

    }

    public static boolean amountValidationZukuNet(String amount)
    {
        if (amount.equals("") || Integer.valueOf(amount) < 500)
            return false;

        else
            return true;

    }

    public static boolean amountValidationTv(String amount)
    {
        if (amount.equals("") || Integer.valueOf(amount) < 500)
            return false;

        else
            return true;

    }

    public static boolean cardNumberValidation(String card_number)
    {
        if (card_number.equals("") || Integer.valueOf(card_number.length()) < 16)
            return false;

        else
            return true;

    }

    public static boolean cardCvvValidation(String card_number)
    {
        if (card_number.equals("") || Integer.valueOf(card_number.length()) < 3)
            return false;

        else
            return true;

    }

    public static boolean cardMonthValidation(String month)
    {
        if (month.equals("") || Integer.valueOf(month) < 1 || Integer.valueOf(month) > 12)
            return false;

        else
            return true;

    }

    public static boolean cardYearValidation(String year)
    {
        if (year.equals(""))
            return false;

        else
            return true;

    }

    public static boolean nameValidation(String name)
    {
        if (name.equals(""))
            return false;

        else
            return true;

    }


}
