package com.ipayafrica.ipay.activities.utils;

public class Model {
    String id, title, icon, status, category;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    /** biller model */
    String billerAccountName, billerCategory, billerAccountType , billerAccountNumber, billerId;

    public String getBillerAccountName() {
        return billerAccountName;
    }

    public void setBillerAccountName(String billerAccountName) {
        this.billerAccountName = billerAccountName;
    }

    public String getBillerCategory() {
        return billerCategory;
    }

    public void setBillerCategory(String billerCategory) {
        this.billerCategory = billerCategory;
    }

    public String getBillerAccountType() {
        return billerAccountType;
    }

    public void setBillerAccountType(String billerAccountType) {
        this.billerAccountType = billerAccountType;
    }

    public String getBillerAccountNumber() {
        return billerAccountNumber;
    }

    public void setBillerAccountNumber(String billerAccountNumber) {
        this.billerAccountNumber = billerAccountNumber;
    }

    public String getBillerId() {
        return billerId;
    }

    public void setBillerId(String billerId) {
        this.billerId = billerId;
    }

    /** account model */
    String accountId, accountName, accountWalletId;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountWalletId() {
        return accountWalletId;
    }

    public void setAccountWalletId(String accountWalletId) {
        this.accountWalletId = accountWalletId;
    }

    /** statement/history model **/
    String statementTransactionId, statementAmount, statementCurr, statementDescription,
            statementReference, statementChannel,statementDate;

    public String getStatementTransactionId() {
        return statementTransactionId;
    }

    public void setStatementTransactionId(String statementTransactionId) {
        this.statementTransactionId = statementTransactionId;
    }

    public String getStatementAmount() {
        return statementAmount;
    }

    public void setStatementAmount(String statementAmount) {
        this.statementAmount = statementAmount;
    }

    public String getStatementCurr() {
        return statementCurr;
    }

    public void setStatementCurr(String statementCurr) {
        this.statementCurr = statementCurr;
    }

    public String getStatementDescription() {
        return statementDescription;
    }

    public void setStatementDescription(String statementDescription) {
        this.statementDescription = statementDescription;
    }

    public String getStatementReference() {
        return statementReference;
    }

    public void setStatementReference(String statementReference) {
        this.statementReference = statementReference;
    }

    public String getStatementChannel() {
        return statementChannel;
    }

    public void setStatementChannel(String statementChannel) {
        this.statementChannel = statementChannel;
    }

    public String getStatementDate() {
        return statementDate;
    }

    public void setStatementDate(String statementDate) {
        this.statementDate = statementDate;
    }

    /** banks model */
    String bankId, bankName, bankNickname, bankPaybill, bankAccountName, bankAccountNumber;

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankNickname() {
        return bankNickname;
    }

    public void setBankNickname(String bankNickname) {
        this.bankNickname = bankNickname;
    }

    public String getBankPaybill() {
        return bankPaybill;
    }

    public void setBankPaybill(String bankPaybill) {
        this.bankPaybill = bankPaybill;
    }

    public String getBankAccountName() {
        return bankAccountName;
    }

    public void setBankAccountName(String bankAccountName) {
        this.bankAccountName = bankAccountName;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    /** notifications */
    String notifyId, notifyTitle, notifyBody, NotifyTime, NotifyFlag;

    public String getNotifyId() {
        return notifyId;
    }

    public void setNotifyId(String notifyId) {
        this.notifyId = notifyId;
    }

    public String getNotifyTitle() {
        return notifyTitle;
    }

    public void setNotifyTitle(String notifyTitle) {
        this.notifyTitle = notifyTitle;
    }

    public String getNotifyBody() {
        return notifyBody;
    }

    public void setNotifyBody(String notifyBody) {
        this.notifyBody = notifyBody;
    }

    public String getNotifyTime() {
        return NotifyTime;
    }

    public void setNotifyTime(String notifyTime) {
        NotifyTime = notifyTime;
    }

    public String getNotifyFlag() {
        return NotifyFlag;
    }

    public void setNotifyFlag(String notifyFlag) {
        NotifyFlag = notifyFlag;
    }
}
