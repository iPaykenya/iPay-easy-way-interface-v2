package com.ipayafrica.ipay.activities.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.ipayafrica.ipay.activities.activities.AddBillerActivity;
import com.ipayafrica.ipay.activities.activities.BillersActivity;
import com.ipayafrica.ipay.activities.activities.HomeActivity;
import com.ipayafrica.ipay.activities.activities.MyWalletActivity;
import com.ipayafrica.ipay.activities.activities.PayBillsActivity;
import com.ipayafrica.ipay.activities.activities.PayBizActivity;
import com.ipayafrica.ipay.activities.activities.ProfileActivity;

import java.util.Map;

public class ScreenExchange {
    public void OnLogin(Context context, String Screen)
    {
        Log.d("loaded_screen", Screen);
        if (Screen.trim().equals("mywallet"))
        {
            ((Activity)context).finish();
            context.startActivity(new Intent(context, MyWalletActivity.class));
            return;
        }

        if (Screen.trim().equals("profile"))
        {
            ((Activity)context).finish();
            context.startActivity(new Intent(context, ProfileActivity.class));
            return;
        }

        if (Screen.trim().equals("pay_business"))
        {
            ((Activity)context).finish();
            PayBizActivity.getInstace().copletePayment();
            return;
        }

        if (Screen.trim().equals("pay_water"))
        {
            String biller = "nairobi_water";
            String url = "/wallet/billing/water";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("postpaid"))
        {
            String biller = "kplc_postpaid";
            String url = "/wallet/billing/electricity";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("prepaid"))
        {
            String biller = "kplc_prepaid";
            String url = "/wallet/billing/electricity";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("zuku_internet"))
        {
            String biller = "zuku";
            String url = "/wallet/billing/tv";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("dstv"))
        {
            String biller = "dstv";
            String url = "/wallet/billing/tv";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("gotv"))
        {
            String biller = "gotv";
            String url = "/wallet/billing/tv";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("zuku"))
        {
            String biller = "zuku";
            String url = "/wallet/billing/tv";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("startimes"))
        {
            String biller = "startimes";
            String url = "/wallet/billing/tv";
            ((Activity)context).finish();
            PayBillsActivity.getInstace().paybillnow(url, biller);
            return;
        }

        if (Screen.trim().equals("airtime"))
        {
            ((Activity)context).finish();
            PayBillsActivity.getInstace().buyAirtimeNow();
            return;
        }

        if (Screen.trim().equals("send_to_elipa_wallet"))
        {
            ((Activity)context).finish();
            PayBillsActivity.getInstace().sendMoneyNow();
            return;
        }

        if (Screen.trim().equals("withdraw"))
        {
            ((Activity)context).finish();
            MyWalletActivity.getInstace().walletWithdraw();
            return;
        }

        if (Screen.trim().equals("wallet_balance"))
        {
            ((Activity)context).finish();
            MyWalletActivity.getInstace().wallet_balance();
            return;
        }

        if (Screen.trim().equals("wallet_card_toptup"))
        {
            ((Activity)context).finish();
            MyWalletActivity.getInstace().walletTopup();
            return;
        }

        if (Screen.trim().equals("Update_Profile"))
        {
            ((Activity)context).finish();
            ProfileActivity.getInstace().saveUpdates();
            return;
        }

        if (Screen.trim().equals("my_billers"))
        {
            ((Activity)context).finish();
            BillersActivity.getInstace().getBiller();
            return;
        }
        if (Screen.trim().equals("select_billers"))
        {
            ((Activity)context).finish();
            PayBillsActivity.getInstace().getBiller();
            return;
        }

        if (Screen.trim().equals("statement"))
        {
            ((Activity)context).finish();
            MyWalletActivity.getInstace().statement();
            return;
        }

        if (Screen.trim().equals("getBanks"))
        {
            ((Activity)context).finish();
            HomeActivity.getInstace().getBanks();
            return;
        }

        if (Screen.trim().equals("add_billers"))
        {
            ((Activity)context).finish();
            AddBillerActivity.getInstace().addBiller();
            return;
        }


        ((Activity)context).finish();
        context.startActivity(new Intent(context, HomeActivity.class));

    }

    /** will show user is loggedin */
    public void showogIn(Context context)
    {
        //get Shared pref
        SharedPreff pref = new SharedPreff();
        Map prefferences = pref.getSharedPref(context);


    }


}
