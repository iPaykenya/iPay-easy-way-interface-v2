package com.ipayafrica.ipay.activities.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.widget.Toast;

import com.ipayafrica.ipay.activities.utils.database.WalletDB;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class SharedPreff {
    public static final String MyPREFERENCES = "MyPrefs" ;

    public void sharedPreffLogin(Context context, String response, String loadScreen)
    {
        JSONObject oprator = null;
        try {

            oprator = new JSONObject(response);

            String header_status = oprator.getString("header_status");

            if (header_status.toString().trim().equals("200")) {
                String access_token = oprator.getString("access_token");
                String wallet_id = oprator.getString("wallet_id");
                String email = oprator.getString("email");
                String fname = oprator.getString("fname");
                String lname = oprator.getString("lname");
                String gender = oprator.getString("gender");
                String verified = oprator.getString("verified");
                String affiliate = oprator.getString("affiliate");
                String password_reset = oprator.getString("password_reset");
                String wallet_balance = oprator.getString("wallet_balance");
                String curr = oprator.getString("curr");
                String referral_code = oprator.getString("referral_code");
                String didate = oprator.getString("didate");
                String shareUrl = oprator.getString("shareUrl");

                SharedPreferences.Editor editor = context.getSharedPreferences(MyPREFERENCES, MODE_PRIVATE).edit();
                editor.putString("token", access_token);
                editor.putString("wallet_id", wallet_id);
                editor.putString("email", email);
                editor.putString("fname", fname);
                editor.putString("lname", lname);
                editor.putString("gender", gender);
                editor.putString("verified", verified);
                editor.putString("affiliate", affiliate);
                editor.putString("password_reset", password_reset);
                editor.putString("wallet_balance", wallet_balance);
                editor.putString("curr", curr);
                editor.putString("referral_code", referral_code);
                editor.putString("shareUrl", shareUrl);
                editor.commit();

                ScreenExchange exchange = new ScreenExchange();
                exchange.OnLogin(context, loadScreen);

                /**initiate sqlite*/
                WalletDB db = new WalletDB(context);
                //check if wallet id exist
                Map<String, String> user = db.getUser(wallet_id);
                String id = user.get("id");
                //add to sqlite if wallet id is empty
                if (TextUtils.isEmpty(id))
                {
                    String name = fname+" "+lname;
                    db.insertUser(name, wallet_id);
                }

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    /** get shared preferences **/
    public Map<String, String> getSharedPref(Context context)
    {
        SharedPreferences editor = context.getSharedPreferences(MyPREFERENCES, MODE_PRIVATE);
        String token = editor.getString("token", "null");
        String wallet_id = editor.getString("wallet_id", "null");
        String email = editor.getString("email", "null");
        String fname = editor.getString("fname", "null");
        String lname = editor.getString("lname", "null");
        String gender = editor.getString("gender", "null");
        String verified = editor.getString("verified", "null");
        String affiliate = editor.getString("affiliate", "null");
        String password_reset = editor.getString("password_reset", "null");
        String wallet_balance = editor.getString("wallet_balance", "null");
        String curr = editor.getString("curr", "null");
        String referral_code = editor.getString("referral_code", "null");
        String shareUrl = editor.getString("shareUrl", "null");

        Map<String, String> pref = new HashMap<>();
        pref.put("token", token);
        pref.put("wallet_id", wallet_id);
        pref.put("email", email);
        pref.put("fname", fname);
        pref.put("lname", lname);
        pref.put("gender", gender);
        pref.put("verified", verified);
        pref.put("affiliate", affiliate);
        pref.put("password_reset", password_reset);
        pref.put("wallet_balance", wallet_balance);
        pref.put("curr", curr);
        pref.put("referral_code", referral_code);
        pref.put("shareUrl", shareUrl);

        return pref;
    }

    public void clearSharedPref(Context context)
    {
        SharedPreferences preferences = context.getSharedPreferences(MyPREFERENCES, MODE_PRIVATE);
        preferences.edit().clear().commit();
    }

}
