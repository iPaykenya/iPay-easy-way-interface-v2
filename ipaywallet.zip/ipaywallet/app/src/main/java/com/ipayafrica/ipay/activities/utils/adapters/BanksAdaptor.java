package com.ipayafrica.ipay.activities.utils.adapters;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.FormValidation;
import com.ipayafrica.ipay.activities.utils.Model;
import com.ipayafrica.ipay.activities.utils.SharedPreff;
import com.ipayafrica.ipay.activities.utils.database.WalletDB;

import java.util.List;
import java.util.Map;

public class BanksAdaptor extends RecyclerView.Adapter<BanksAdaptor.MyViewHolder>{

    private List<Model> models;
    private Context mContext;

    String v;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        EditText back_acc_name, back_acc_number;
        TextView bank_initial, bank_name, bank_nickname;
        Button bank_select, bank_save, bank_close;
        LinearLayout bank_details;

        public MyViewHolder(View view) {
            super(view);

            back_acc_name       = (EditText) view.findViewById(R.id.back_acc_name);
            back_acc_number     = (EditText) view.findViewById(R.id.back_acc_number);
            bank_initial        = (TextView) view.findViewById(R.id.bank_initial);
            bank_name           = (TextView) view.findViewById(R.id.bank_name);
            bank_nickname       = (TextView) view.findViewById(R.id.bank_nickname);
            bank_select         = (Button) view.findViewById(R.id.bank_select);
            bank_save           = (Button) view.findViewById(R.id.bank_save);
            bank_close          = (Button) view.findViewById(R.id.bank_close);
            bank_details        = (LinearLayout) view.findViewById(R.id.bank_details);

        }
    }


    public BanksAdaptor(Context context, List<Model> models) {
        mContext = context;
        this.models = models;
    }

    @Override
    public BanksAdaptor.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layoutbankslist, parent, false);

        return new BanksAdaptor.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final BanksAdaptor.MyViewHolder holder, final int position) {

        final Model model = models.get(position);

        holder.bank_initial.setText(model.getBankNickname());
        holder.bank_name.setText(model.getBankName());
        holder.bank_nickname.setText(model.getBankNickname());

        holder.bank_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.bank_select.setVisibility(View.GONE);
                holder.bank_details.setVisibility(View.VISIBLE);
            }
        });

        holder.bank_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String accName = holder.back_acc_name.getText().toString().trim();
                String accNumber = holder.back_acc_number.getText().toString().trim();

                if (FormValidation.accountValidation(accName) == false) {
                    Toast.makeText(mContext, "invalid account name", Toast.LENGTH_LONG).show();
                    return;
                }

                if (FormValidation.accountValidation(accNumber) == false) {
                    Toast.makeText(mContext, "invalid account number", Toast.LENGTH_LONG).show();
                    return;
                }
                /**initiate sqlite*/
                WalletDB db = new WalletDB(mContext);
                //check if account number exist
                Map<String, String> bank = db.getBank(accNumber);
                String account_number = bank.get("account_number");
                //add to sqlite if bank acc is empty
                if (!TextUtils.isEmpty(account_number))
                {
                    Toast.makeText(mContext, "account number exist", Toast.LENGTH_LONG).show();
                    return;
                }

                SharedPreff pref = new SharedPreff();
                Map prefferences = pref.getSharedPref(mContext);

                String walletid     =  String.valueOf(prefferences.get("wallet_id"));

                long inserted = db.insertBank(model.getBankName(), model.getBankNickname(), model.getBankPaybill(), accName, accNumber, walletid);
                Toast.makeText(mContext, "account added... ", Toast.LENGTH_LONG).show();
                holder.bank_select.setVisibility(View.VISIBLE);
                holder.bank_details.setVisibility(View.GONE);
                holder.back_acc_name.setText("");
                holder.back_acc_number.setText("");

            }
        });

        holder.bank_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.bank_select.setVisibility(View.VISIBLE);
                holder.bank_details.setVisibility(View.GONE);
                holder.back_acc_name.setText("");
                holder.back_acc_number.setText("");
            }
        });


    }


    @Override
    public int getItemCount() {
        return models.size();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private BanksAdaptor.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final BanksAdaptor.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    //check internet connection
    public static boolean isConnectingToInternet(Context context)
    {
        ConnectivityManager connectivity =
                (ConnectivityManager) context.getSystemService(
                        Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }
        }
        return false;
    }

}
