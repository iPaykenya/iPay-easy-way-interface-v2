package com.ipayafrica.ipay.activities.utils.adapters;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.Model;

import java.util.List;

public class BillersAdaptor extends RecyclerView.Adapter<BillersAdaptor.MyViewHolder>{

    private List<Model> models;
    private Context mContext;

    String v;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView biller_name, biller_account, initial;
        ImageView biller_menu;

        public MyViewHolder(View view) {
            super(view);

            biller_name           = (TextView) view.findViewById(R.id.biller_name);
            biller_account        = (TextView) view.findViewById(R.id.biller_account);
            initial               = (TextView) view.findViewById(R.id.initial);
            biller_menu           = (ImageView) view.findViewById(R.id.biller_menu);

        }
    }


    public BillersAdaptor(Context context, List<Model> models) {
        mContext = context;
        this.models = models;
    }

    @Override
    public BillersAdaptor.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layoutbillers, parent, false);

        return new BillersAdaptor.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final BillersAdaptor.MyViewHolder holder, final int position) {

        final Model model = models.get(position);

        holder.biller_name.setText(model.getBillerAccountName());
        holder.biller_account.setText(model.getBillerAccountNumber());
        holder.initial.setText(model.getBillerAccountName());

        holder.biller_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu(holder.biller_menu , position);
                //Toast.makeText(mContext, ""+model.getBillerAccountName(), Toast.LENGTH_SHORT).show();
            }
        });


    }

    //popup here
    private void showPopupMenu(View view,int position) {
        // inflate menu
        PopupMenu popup = new PopupMenu(view.getContext(),view );
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.biller_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(new BillersAdaptor.MyMenuItemClickListener(position));
        popup.show();
    }


    @Override
    public int getItemCount() {
        return models.size();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private BillersAdaptor.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final BillersAdaptor.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    //check internet connection
    public static boolean isConnectingToInternet(Context context)
    {
        ConnectivityManager connectivity =
                (ConnectivityManager) context.getSystemService(
                        Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }
        }
        return false;
    }

    class MyMenuItemClickListener implements PopupMenu.OnMenuItemClickListener {

        private int position;
        public MyMenuItemClickListener(int positon) {
            this.position=positon;
        }

        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            switch (menuItem.getItemId()) {

                case R.id.menu_pay_now:
                    Toast.makeText(mContext, "pay now", Toast.LENGTH_SHORT).show();
                    return true;

                case R.id.menu_edit:
                    Toast.makeText(mContext, "edit now", Toast.LENGTH_SHORT).show();
                    return true;
                case R.id.menu_delete:
                    Toast.makeText(mContext, "delete now", Toast.LENGTH_SHORT).show();
                    return true;
                default:
            }
            return false;
        }
    }

}
