package com.ipayafrica.ipay.activities.utils.adapters;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.Model;

import java.util.List;

public class NotifyAdaptor extends RecyclerView.Adapter<NotifyAdaptor.MyViewHolder> {

    private List<Model> models;
    private Context mContext;

    String v;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        LinearLayout notify;
        TextView notify_image,notify_title, notify_body, notify_time;

        public MyViewHolder(View view) {
            super(view);

            notify       = (LinearLayout) view.findViewById(R.id.notify);
            notify_image = (TextView) view.findViewById(R.id.notify_image);
            notify_title = (TextView) view.findViewById(R.id.notify_title);
            notify_body = (TextView) view.findViewById(R.id.notify_body);
            notify_time = (TextView) view.findViewById(R.id.notify_time);


        }
    }


    public NotifyAdaptor(Context context, List<Model> models) {
        mContext = context;
        this.models = models;
    }

    @Override
    public NotifyAdaptor.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layoutnotification, parent, false);

        return new NotifyAdaptor.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final NotifyAdaptor.MyViewHolder holder, final int position) {

        final Model model = models.get(position);

        holder.notify_image.setText(model.getNotifyBody());
        holder.notify_title.setText(model.getNotifyTitle());
        holder.notify_body.setText(model.getNotifyBody());
        holder.notify_time.setText(model.getNotifyTime());

        if (model.getNotifyFlag().toString().equals("NEW"))
        {
            Toast.makeText(mContext, "new ", Toast.LENGTH_SHORT).show();
            holder.notify.setBackgroundColor(holder.notify.getContext().getResources().getColor(R.color.colorText));
        }
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private NotifyAdaptor.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final NotifyAdaptor.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    //check internet connection
    public static boolean isConnectingToInternet(Context context) {
        ConnectivityManager connectivity =
                (ConnectivityManager) context.getSystemService(
                        Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
        }
        return false;
    }

}
