package com.ipayafrica.ipay.activities.utils.adapters;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.Model;

import java.util.List;

public class SendMoneyBankAdaptor extends RecyclerView.Adapter<SendMoneyBankAdaptor.MyViewHolder>{

    private List<Model> models;
    private Context mContext;

    String v;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView back_acc_name, back_acc_number, bank_nickname, bank_initial;
        Button cached_account_delete, cached_account_select;

        public MyViewHolder(View view) {
            super(view);


            back_acc_name           = (TextView) view.findViewById(R.id.account_name_cached);
            back_acc_number         = (TextView) view.findViewById(R.id.account_number_cached);
            bank_nickname           = (TextView) view.findViewById(R.id.bank_nickname_cached);
            bank_initial            = (TextView) view.findViewById(R.id.bank_cached_initial);
            cached_account_delete   = (Button) view.findViewById(R.id.cached_account_delete);
            cached_account_select   = (Button) view.findViewById(R.id.cached_account_select);


        }
    }


    public SendMoneyBankAdaptor(Context context, List<Model> models) {
        mContext = context;
        this.models = models;
    }

    @Override
    public SendMoneyBankAdaptor.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layoutbankscachedlist, parent, false);

        return new SendMoneyBankAdaptor.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final SendMoneyBankAdaptor.MyViewHolder holder, final int position) {

        final Model model = models.get(position);

        holder.bank_initial.setText(model.getBankNickname());
        holder.back_acc_name.setText(model.getBankAccountName());
        holder.back_acc_number.setText(model.getBankAccountNumber());
        holder.bank_nickname.setText(model.getBankNickname());

        holder.cached_account_select.setVisibility(View.VISIBLE);

//        holder.cached_account_delete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                /**initiate sqlite*/
//                WalletDB db = new WalletDB(mContext);
//                db.deleteBank(model.getBankAccountNumber());
//                HomeActivity.getInstace().mPopupWindow.dismiss();
//            }
//        });

        holder.cached_account_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext, "used to send money to bank b2b only ", Toast.LENGTH_SHORT).show();
            }
        });

    }


    @Override
    public int getItemCount() {
        return models.size();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private SendMoneyBankAdaptor.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final SendMoneyBankAdaptor.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    //check internet connection
    public static boolean isConnectingToInternet(Context context)
    {
        ConnectivityManager connectivity =
                (ConnectivityManager) context.getSystemService(
                        Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }
        }
        return false;
    }

}
