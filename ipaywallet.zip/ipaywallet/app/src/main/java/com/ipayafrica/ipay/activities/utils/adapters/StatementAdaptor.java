package com.ipayafrica.ipay.activities.utils.adapters;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.utils.Model;

import java.util.List;

public class StatementAdaptor extends RecyclerView.Adapter<StatementAdaptor.MyViewHolder> {

    private List<Model> models;
    private Context mContext;

    String v;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView history_ref_code, history_description, history_channel, history_date;

        public MyViewHolder(View view) {
            super(view);

            history_ref_code    = (TextView) view.findViewById(R.id.history_ref_code);
            history_description = (TextView) view.findViewById(R.id.history_description);
            history_channel     = (TextView) view.findViewById(R.id.history_channel);
            history_date     = (TextView) view.findViewById(R.id.history_date);

        }
    }


    public StatementAdaptor(Context context, List<Model> models) {
        mContext = context;
        this.models = models;
    }

    @Override
    public StatementAdaptor.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layouthistorylist, parent, false);

        return new StatementAdaptor.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final StatementAdaptor.MyViewHolder holder, final int position) {

        final Model model = models.get(position);

        holder.history_ref_code.setText(model.getStatementReference());
        holder.history_description.setText(model.getStatementDescription()+".");
        holder.history_channel.setText("Channel used is "+model.getStatementChannel()+", "+"Total amount is "+model.getStatementCurr()+" "+model.getStatementAmount()+".");
        holder.history_date.setText(model.getStatementDate());

    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private StatementAdaptor.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final StatementAdaptor.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    //check internet connection
    public static boolean isConnectingToInternet(Context context) {
        ConnectivityManager connectivity =
                (ConnectivityManager) context.getSystemService(
                        Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
        }
        return false;
    }
}

