package com.ipayafrica.ipay.activities.utils.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.ipayafrica.ipay.activities.utils.SharedPreff;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class WalletDB {
    private WalletDBHelper mHelper;
    String walletid;

    public WalletDB(Context context){
        mHelper = new WalletDBHelper(context);

        SharedPreff pref = new SharedPreff();
        Map prefferences = pref.getSharedPref(context);
        walletid     =  String.valueOf(prefferences.get("wallet_id"));

    }

    /**< notifications **/
    public long insertNotification(String title, String Msg, String time, String Flag) {
        SQLiteDatabase dbb = mHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(WalletDBHelper.NOTIFICATION_TITLE, title);
        contentValues.put(WalletDBHelper.NOTIFICATION_BODY, Msg);
        contentValues.put(WalletDBHelper.NOTIFICATION_TIME, time);
        contentValues.put(WalletDBHelper.NOTIFICATION_FLAG, Flag);
        contentValues.put(WalletDBHelper.WALLET_ID_COLUMN, walletid);
        long id = dbb.insert(WalletDBHelper.NOTIFICATION_TABLE_NAME, null , contentValues);
        return id;
    }

    public JSONArray getNotifications()
    {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String[] columns = {WalletDBHelper.NOTIFICATION_UID,
                WalletDBHelper.NOTIFICATION_TITLE,
                WalletDBHelper.NOTIFICATION_BODY,
                WalletDBHelper.NOTIFICATION_TIME,
                WalletDBHelper.NOTIFICATION_FLAG};

        Cursor cursor =db.query(WalletDBHelper.NOTIFICATION_TABLE_NAME,columns,null,null,null,null,null);
        //StringBuffer buffer= new StringBuffer();

        JSONArray jsonArray = new JSONArray();
        while (cursor.moveToNext())
        {
            int tid =cursor.getInt(cursor.getColumnIndex(WalletDBHelper.NOTIFICATION_UID));
            String title =cursor.getString(cursor.getColumnIndex(WalletDBHelper.NOTIFICATION_TITLE));
            String body =cursor.getString(cursor.getColumnIndex(WalletDBHelper.NOTIFICATION_BODY));
            String time =cursor.getString(cursor.getColumnIndex(WalletDBHelper.NOTIFICATION_TIME));
            String  flag =cursor.getString(cursor.getColumnIndex(WalletDBHelper.NOTIFICATION_FLAG));
            JSONObject user = new JSONObject();
            try {
                user.put("id", ""+tid);
                user.put("title", title);
                user.put("body", body);
                user.put("time", time);
                user.put("flag",flag);
                jsonArray.put(user);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return jsonArray;
    }
    /** notifications />**/


    /** users create starts **/
    public long insertUser(String name, String walletId)
    {
        SQLiteDatabase dbb = mHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(WalletDBHelper.USER_NAME, name);
        contentValues.put(WalletDBHelper.WALLET_ID_COLUMN, walletId);
        long id = dbb.insert(WalletDBHelper.USER_TABLE_NAME, null , contentValues);
        return id;
    }

    public JSONArray getAllUser()
    {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String[] columns = {WalletDBHelper.USER_TABLE_ID,
                        WalletDBHelper.USER_NAME,
                        WalletDBHelper.WALLET_ID_COLUMN};

        Cursor cursor =db.query(WalletDBHelper.USER_TABLE_NAME,columns,null,null,null,null,null);
        //StringBuffer buffer= new StringBuffer();

        JSONArray jsonArray = new JSONArray();
        while (cursor.moveToNext())
        {
            int tid =cursor.getInt(cursor.getColumnIndex(WalletDBHelper.USER_TABLE_ID));
            String name =cursor.getString(cursor.getColumnIndex(WalletDBHelper.USER_NAME));
            String  walletid =cursor.getString(cursor.getColumnIndex(WalletDBHelper.WALLET_ID_COLUMN));
            JSONObject user = new JSONObject();
            try {
                user.put("id", ""+tid);
                user.put("name", name);
                user.put("phone",walletid);
                jsonArray.put(user);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return jsonArray;
    }

    public Map<String, String> getUser(String walletId)
    {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String[] columns = {WalletDBHelper.USER_TABLE_ID,
                WalletDBHelper.USER_NAME,
                WalletDBHelper.WALLET_ID_COLUMN};

        Cursor cursor =db.query(WalletDBHelper.USER_TABLE_NAME,columns,WalletDBHelper.WALLET_ID_COLUMN +"=" +walletId,null,null,null,null);

        Map<String, String > user = new HashMap<>();

        while (cursor.moveToNext())
        {
            int tid =cursor.getInt(cursor.getColumnIndex(WalletDBHelper.USER_TABLE_ID));
            String name =cursor.getString(cursor.getColumnIndex(WalletDBHelper.USER_NAME));
            String  walletid =cursor.getString(cursor.getColumnIndex(WalletDBHelper.WALLET_ID_COLUMN));
            user.put("id", ""+tid);
            user.put("name", name);
            user.put("walletId", walletId);
        }
        return user;
    }

    public int deleteUser(String walletId)
    {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String[] whereArgs ={walletId};

        int count =db.delete(mHelper.USER_TABLE_NAME ,mHelper.WALLET_ID_COLUMN+" = ?",whereArgs);
        return  count;
    }

    /** users create end **/

    /**< bank create */
    public long insertBank(String name, String nickname, String paybill, String acc_name, String acc_number, String walletId)
    {
        SQLiteDatabase dbb = mHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(WalletDBHelper.BANK_NAME, name);
        contentValues.put(WalletDBHelper.BANK_NICKNAME, nickname);
        contentValues.put(WalletDBHelper.BANK_PAYBILL, paybill);
        contentValues.put(WalletDBHelper.BANK_ACCOUNT_NAME, acc_name);
        contentValues.put(WalletDBHelper.BANK_ACCOUNT_NUMBER, acc_number);
        contentValues.put(WalletDBHelper.WALLET_ID_COLUMN, walletId);
        long id = dbb.insert(WalletDBHelper.BANK_TABLE_NAME, null , contentValues);
        return id;
    }

    public JSONArray getAllBanks(String walletId)
    {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String[] columns = {WalletDBHelper.BANK_TABLE_ID,
                WalletDBHelper.BANK_NAME,
                WalletDBHelper.BANK_NICKNAME,
                WalletDBHelper.BANK_PAYBILL,
                WalletDBHelper.BANK_ACCOUNT_NAME,
                WalletDBHelper.BANK_ACCOUNT_NUMBER,
                WalletDBHelper.WALLET_ID_COLUMN};

        Cursor cursor =db.query(WalletDBHelper.BANK_TABLE_NAME,columns,WalletDBHelper.WALLET_ID_COLUMN +"=" +walletId,null,null,null,null);
        //StringBuffer buffer= new StringBuffer();

        JSONArray jsonArray = new JSONArray();
        while (cursor.moveToNext())
        {
            int tid =cursor.getInt(cursor.getColumnIndex(WalletDBHelper.BANK_TABLE_ID));
            String name =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_NAME));
            String nickname =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_NICKNAME));
            String paybill =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_PAYBILL));
            String acc_name =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_ACCOUNT_NAME));
            String acc_number =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_ACCOUNT_NUMBER));
            String walletid =cursor.getString(cursor.getColumnIndex(WalletDBHelper.WALLET_ID_COLUMN));
            JSONObject banks = new JSONObject();
            try {
                banks.put("id", ""+tid);
                banks.put("name", name);
                banks.put("nickname", nickname);
                banks.put("paybill", paybill);
                banks.put("accountname", acc_name);
                banks.put("accountnumber", acc_number);
                banks.put("phone",walletid);
                jsonArray.put(banks);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return jsonArray;
    }

    //get single bank
    public Map<String, String> getBank(String acc_number)
    {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String[] columns = {WalletDBHelper.BANK_TABLE_ID,
                WalletDBHelper.BANK_NAME,
                WalletDBHelper.BANK_NICKNAME,
                WalletDBHelper.BANK_PAYBILL,
                WalletDBHelper.BANK_ACCOUNT_NAME,
                WalletDBHelper.BANK_ACCOUNT_NUMBER,
                WalletDBHelper.WALLET_ID_COLUMN};
        String[] arg = {acc_number};

        Cursor cursor =db.query(WalletDBHelper.BANK_TABLE_NAME,columns,  WalletDBHelper.BANK_ACCOUNT_NUMBER +"=?" ,arg,null,null,null);

        Map<String, String > bank = new HashMap<>();

        while (cursor.moveToNext())
        {
            int tid =cursor.getInt(cursor.getColumnIndex(WalletDBHelper.BANK_TABLE_ID));
            String name =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_NAME));
            String nickname =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_NICKNAME));
            String paybill =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_PAYBILL));
            String acc_name =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_ACCOUNT_NAME));
            String account_number =cursor.getString(cursor.getColumnIndex(WalletDBHelper.BANK_ACCOUNT_NUMBER));
            String  walletid =cursor.getString(cursor.getColumnIndex(WalletDBHelper.WALLET_ID_COLUMN));
            bank.put("id", ""+tid);
            bank.put("name", name);
            bank.put("nickname", nickname);
            bank.put("paybill", paybill);
            bank.put("acc_name", acc_name);
            bank.put("account_number", account_number);
            bank.put("walletId", walletid);
        }
        return bank;
    }

    public int deleteBank(String accountnumber)
    {
        SQLiteDatabase db = mHelper.getWritableDatabase();
        String[] whereArgs ={accountnumber};

        int count =db.delete(mHelper.BANK_TABLE_NAME ,mHelper.BANK_ACCOUNT_NUMBER+" = ?",whereArgs);
        return  count;
    }

    /** bank create />*/

    private static class WalletDBHelper extends SQLiteOpenHelper {

        private static final String DATABASE_NAME                     =               "iPayWalletDB";
        private static final String WALLET_ID_COLUMN                  =               "iPayWalletID";

        /** notifications table */
        private static final String NOTIFICATION_TABLE_NAME           =               "NOTIFICATION";
        private static final String NOTIFICATION_UID                  =               "notification_id";
        private static final String NOTIFICATION_TITLE                 =               "notification_title";
        private static final String NOTIFICATION_BODY                 =               "notification_body";
        private static final String NOTIFICATION_TIME                 =               "notification_time";
        private static final String NOTIFICATION_FLAG                 =               "notification_flag";
        private static final String CREATE_TABLE_NOTIFICATION = "CREATE TABLE " + NOTIFICATION_TABLE_NAME + "("
                + NOTIFICATION_UID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NOTIFICATION_TITLE + " VARCHAR(40),"
                + NOTIFICATION_BODY + " VARCHAR(500),"
                + NOTIFICATION_TIME + " VARCHAR(40),"
                + NOTIFICATION_FLAG + " VARCHAR(10),"
                + WALLET_ID_COLUMN + " VARCHAR(15)"
                +");";

        private static final String DROP_TABLE_NOTIFICATION = " DROP TABLE IF EXISTS " + NOTIFICATION_TABLE_NAME + ";";


        /** users table */
        private static final String USER_TABLE_NAME      =               "USER";
        private static final String USER_TABLE_ID        =               "ID";
        private static final String USER_NAME            =               "USER_NAME";
        private static final String CREATE_TABLE_USER = "CREATE TABLE " + USER_TABLE_NAME + "("
                + USER_TABLE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_NAME + " VARCHAR(15),"
                + WALLET_ID_COLUMN + " VARCHAR(15) not null unique"
                +");";

        private static final String DROP_TABLE_USER = " DROP TABLE IF EXISTS " + USER_TABLE_NAME + ";";

        /** bank account table */
        private static final String BANK_TABLE_NAME      =               "BANK";
        private static final String BANK_TABLE_ID        =               "ID";
        private static final String BANK_NAME            =               "BANK_NAME";
        private static final String BANK_NICKNAME        =               "BANK_NICKNAME";
        private static final String BANK_PAYBILL         =               "BANK_PAYBILL";
        private static final String BANK_ACCOUNT_NAME    =               "BANK_ACCOUNT_NAME";
        private static final String BANK_ACCOUNT_NUMBER  =               "BANK_ACCOUNT_NUMBER";
        private static final String CREATE_TABLE_BANK = "CREATE TABLE " + BANK_TABLE_NAME + "("
                + BANK_TABLE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + BANK_NAME + " VARCHAR(255),"
                + BANK_NICKNAME + " VARCHAR(255),"
                + BANK_PAYBILL + " VARCHAR(50),"
                + BANK_ACCOUNT_NAME + " VARCHAR(255),"
                + BANK_ACCOUNT_NUMBER + " VARCHAR(255) not null unique,"
                + WALLET_ID_COLUMN + " VARCHAR(15)"
                +");";

        private static final String DROP_TABLE_BANK = " DROP TABLE IF EXISTS " + BANK_TABLE_NAME + ";";



        /*--------------------------------------
         **contact history table stores all contactacts used in buying credit
         */
        //contact history
        private static final String CONTACTS_HISTORY_TABLE_NAME           =               "CONTACTS_HISTORY";
        private static final String CONTACTS_HISTORY_TID                  =               "CONTACTS_HISTORY_id";
        private static final String PHONE_NUMBER                          =               "PHONE_NUMBER";
        private static final String OPERATOR                              =               "OPERATOR";
        private static final String CREATE_TABLE_CONTACTS_HISTORY = "CREATE TABLE " + CONTACTS_HISTORY_TABLE_NAME + "("
                + CONTACTS_HISTORY_TID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + PHONE_NUMBER + " VARCHAR(15),"
                + OPERATOR + " VARCHAR(50),"
                + WALLET_ID_COLUMN + " VARCHAR(15)"
                +");";

        private static final String DROP_TABLE_CONTACTS_HISTORY = " DROP TABLE IF EXISTS " + CONTACTS_HISTORY_TABLE_NAME + ";";

        //Billers
        private static final String BILLERS_TABLE_NAME           =               "BILLERS";
        private static final String BILLERS_UID                  =               "billers_id";
        private static final String BILLERS_UTILITY              =               "billers_utility";
        private static final String BILLERS_PRODUCT              =               "billers_product";
        private static final String BILLERS_NICKNAME             =               "billers_nickname";
        private static final String BILLERS_ACCOUNT_NO           =               "billers_account_no";
        private static final String BILLERS_ONLINE_ID           =               "billers_online_id";
        private static final String CREATE_TABLE_BILLERS         = "CREATE TABLE " + BILLERS_TABLE_NAME + "("
                + BILLERS_UID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + BILLERS_UTILITY + " VARCHAR(10),"
                + BILLERS_PRODUCT + " VARCHAR(10),"
                + BILLERS_NICKNAME + " VARCHAR(20),"
                + BILLERS_ACCOUNT_NO + " VARCHAR(20),"
                + WALLET_ID_COLUMN + " VARCHAR(15),"
                + BILLERS_ONLINE_ID + " VARCHAR(20)"
                +");";
        private static final String DROP_TABLE_BILLERS = " DROP TABLE IF EXISTS " + BILLERS_TABLE_NAME + ";";

        private static final String COUNT_TABLE_ROWS = "SELECT COUNT(*) FROM ";
        private static final int DATABASE_VERSION = 5;
        private Context mContext;

        public WalletDBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            this.mContext = context;
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(CREATE_TABLE_CONTACTS_HISTORY);
                db.execSQL(CREATE_TABLE_NOTIFICATION);
                db.execSQL(CREATE_TABLE_BILLERS);
                db.execSQL(CREATE_TABLE_USER);
                db.execSQL(CREATE_TABLE_BANK);
            } catch (SQLException e) {
                //L.m("SQLException onCreate " + e);
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                db.execSQL(DROP_TABLE_CONTACTS_HISTORY);
                db.execSQL(DROP_TABLE_NOTIFICATION);
                db.execSQL(DROP_TABLE_BILLERS);
                db.execSQL(DROP_TABLE_USER);
                db.execSQL(DROP_TABLE_BANK);
                onCreate(db);

            } catch (SQLException e) {
                //L.m("SQLException onUpgrade " + e);
            }
        }

        @Override
        public void onOpen(SQLiteDatabase db) {
            super.onOpen(db);
        }
    }
}
