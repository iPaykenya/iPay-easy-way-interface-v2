package com.ipayafrica.ipay.activities.utils.firebase;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.ipayafrica.ipay.R;
import com.ipayafrica.ipay.activities.activities.NotificationActivity;
import com.ipayafrica.ipay.activities.utils.database.WalletDB;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";
    String title, message, time, Flag;
    Date date;
    DateFormat dateFormat;

    private static MyFirebaseMessagingService sInstance;

//    public static MyFirebaseMessagingService getInstance() {
//        return sInstance;
//    }

    public static Context getAppContext() {
        return sInstance.getApplicationContext();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        date = new Date();
        String strDateFormat = "yyyy/M/dd hh:mm:ss a";
        dateFormat = new SimpleDateFormat(strDateFormat);
        sInstance = this;
    }


    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
    @Override
        public void onMessageReceived(RemoteMessage remoteMessage) {

        /**initiate sqlite*/
        WalletDB db = new WalletDB(getAppContext());

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            title   = "eLipa";
            Flag    = "NEW";
            message = remoteMessage.getNotification().getBody();
            time    = dateFormat.format(date);

            db.insertNotification(title, message, time, Flag);
        }

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            title = ""+remoteMessage.getData().get("key2");
            Flag    = "NEW";
            message = ""+remoteMessage.getData().get("key1");
            time    = dateFormat.format(date);

            db.insertNotification(title, message, time, Flag);
        }

        processNotification(message);
    }


    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param messageBody FCM message body received.
     */
    private void processNotification( String messageBody) {
        Intent intent = new Intent(this, NotificationActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent,
                PendingIntent.FLAG_CANCEL_CURRENT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        String title= getString(R.string.app_name);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(messageBody)
                .setTicker(title)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
    }

}