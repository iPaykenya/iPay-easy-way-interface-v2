package com.ipayafrica.ipay.activities.utils.volley;

public interface VolleyCallBack {
    void onSuccess(String result);
}

