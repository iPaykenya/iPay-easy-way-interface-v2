package com.ipayafrica.ipay.activities.utils.volley;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ipayafrica.ipay.activities.utils.AES_Cipher;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class VolleyStringRequest {

    private ProgressDialog mAuthProgressDialog;

    public void postDataLogin(final Context contxt, final Map<String, String> params, final HashMap<String, String> header, String url, final VolleyCallBack callback) {

        String my_key = null, my_iv = null;
        ApplicationInfo ai = null;
        try {
            ai = contxt.getPackageManager().getApplicationInfo(contxt.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            my_key = bundle.getString("my_key");
            my_iv = bundle.getString("my_iv");
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        /**call encryption func*/
        JSONObject data = new JSONObject(params);
        AES_Cipher aes_cipher = new AES_Cipher(contxt);
        final String encrypted = aes_cipher.encrypt(""+data, my_key, my_iv);
        /** encryption end*/

        mAuthProgressDialog = new ProgressDialog(contxt);
        mAuthProgressDialog.setMessage("loading please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        StringRequest request = new StringRequest(Request.Method.POST, ""+url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mAuthProgressDialog.hide();

                        callback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                mAuthProgressDialog.hide();
                VolleyValidation.volleyErrorResponseLogin(contxt, error);

            }

        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parameters = new HashMap<>();
                parameters.put("data", encrypted);
                return parameters;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> map = header;
                return map;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(contxt);
        requestQueue.add(request);

    }


    public void postData(final Context contxt, final Map<String, String> params, final HashMap<String, String> header, String url, final VolleyCallBack callback) {

        String my_key = null, my_iv = null;
        ApplicationInfo ai = null;
        try {
            ai = contxt.getPackageManager().getApplicationInfo(contxt.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            my_key = bundle.getString("my_key");
            my_iv = bundle.getString("my_iv");
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        /**call encryption func*/
        JSONObject data = new JSONObject(params);
        AES_Cipher aes_cipher = new AES_Cipher(contxt);
        final String encrypted = aes_cipher.encrypt(""+data, my_key, my_iv);
        /** encryption end*/

        mAuthProgressDialog = new ProgressDialog(contxt);
        mAuthProgressDialog.setMessage("loading please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        StringRequest request = new StringRequest(Request.Method.POST, ""+url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mAuthProgressDialog.hide();

                        callback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                mAuthProgressDialog.hide();
                VolleyValidation.volleyErrorResponse(contxt, error);

            }

        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parameters = new HashMap<>();
                parameters.put("data", encrypted);
                return parameters;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> map = header;
                return map;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(contxt);
        requestQueue.add(request);

    }


    public void getData(final Context contxt, final Map<String, String> params, final HashMap<String, String> header, String url, final VolleyCallBack callback) {

        String my_key = null, my_iv = null;
        ApplicationInfo ai = null;
        try {
            ai = contxt.getPackageManager().getApplicationInfo(contxt.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            my_key = bundle.getString("my_key");
            my_iv = bundle.getString("my_iv");
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        /**call encryption func*/
        JSONObject data = new JSONObject(params);
        AES_Cipher aes_cipher = new AES_Cipher(contxt);
        final String encrypted = aes_cipher.encrypt(""+data, my_key, my_iv);
        /** encryption end*/

//        Log.d("data_to_save", ""+params);
//        Log.d("encry", ""+encrypted);
//        Log.d("data_save_url", url);
//        Log.d("data_header", ""+header);

        mAuthProgressDialog = new ProgressDialog(contxt);
        mAuthProgressDialog.setMessage("loading please wait...");
        mAuthProgressDialog.setCancelable(false);
        mAuthProgressDialog.show();

        StringRequest request = new StringRequest(Request.Method.GET, ""+url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mAuthProgressDialog.hide();

                        callback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                mAuthProgressDialog.hide();
                VolleyValidation.volleyErrorResponse(contxt, error);

            }

        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parameters = new HashMap<>();
                parameters.put("data", encrypted);
                return parameters;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> map = header;
                return map;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(contxt);
        requestQueue.add(request);
    }

}
