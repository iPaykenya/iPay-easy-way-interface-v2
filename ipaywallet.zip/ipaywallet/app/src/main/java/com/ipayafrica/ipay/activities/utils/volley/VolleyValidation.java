package com.ipayafrica.ipay.activities.utils.volley;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class VolleyValidation {
    public static void volleyErrorResponse(Context mContext, VolleyError error)
    {
        NetworkResponse response = error.networkResponse;

        if (response != null && response.data != null) {

            String json = "";
            JSONObject obj; json = new String(response.data);
            Log.d("error_occired", json);

            switch (response.statusCode) {

                case 401:
                    //Toast.makeText(LoginActivity.this, "invalid credentials", Toast.LENGTH_SHORT).show();
                    break;

                case 403:
                    json = new String(response.data);

                    Toast.makeText(mContext, "System verification error! please try again.", Toast.LENGTH_LONG).show();

//                    try {
//                        obj = new JSONObject(json);
//
//                        Toast.makeText(mContext, ""+obj.getString("text"), Toast.LENGTH_SHORT).show();
//
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
                    break;
                case 400:

//                    json = new String(response.data);//string
//                    try {
//                        JSONObject oprator = new JSONObject(json);
//                        String text = oprator.getString("text");
//
//                            JSONArray mJsonArray = new JSONArray(text);
//                            JSONObject mJsonObject = mJsonArray.getJSONObject(0);
//                            String msg = mJsonObject.getString("message");
//                            Toast.makeText(mContext, ""+msg, Toast.LENGTH_LONG).show();
//
//
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }

                    Toast.makeText(mContext, "Error processing data", Toast.LENGTH_LONG).show();
                    break;
                default:
                    Toast.makeText(mContext, "System error occurred! please try again", Toast.LENGTH_LONG).show();
                    break;

            }
        } else {
            volleyErrors(mContext, error);
        }
    }

    public static void volleyErrorResponseLogin(Context mContext, VolleyError error)
    {
        NetworkResponse response = error.networkResponse;

        if (response != null && response.data != null) {

            String json = "";
            JSONObject obj; json = new String(response.data);
           // Log.d("error_occired", json);

            switch (response.statusCode) {

                case 401:
                    //Toast.makeText(LoginActivity.this, "invalid credentials", Toast.LENGTH_SHORT).show();
                    break;

                case 403:
                    json = new String(response.data);

                    Toast.makeText(mContext, "Invalid credentials.", Toast.LENGTH_LONG).show();

//                    try {
//                        obj = new JSONObject(json);
//
//                        Toast.makeText(mContext, ""+obj.getString("text"), Toast.LENGTH_SHORT).show();
//
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
                    break;
                case 400:

//                    json = new String(response.data);//string
//                    try {
//                        JSONObject oprator = new JSONObject(json);
//                        String text = oprator.getString("text");
//
//                            JSONArray mJsonArray = new JSONArray(text);
//                            JSONObject mJsonObject = mJsonArray.getJSONObject(0);
//                            String msg = mJsonObject.getString("message");
//                            Toast.makeText(mContext, ""+msg, Toast.LENGTH_LONG).show();
//
//
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }

                    Toast.makeText(mContext, "Error processing data", Toast.LENGTH_LONG).show();
                    break;
                default:
                    Toast.makeText(mContext, "System error occurred! please try again", Toast.LENGTH_LONG).show();
                    break;

            }
        } else {
            volleyErrors(mContext, error);
        }
    }


    //volley validations
    public static void volleyErrors(Context mContext, VolleyError error)
    {

        String message = null;
        if (error instanceof NetworkError) {
            message = "Cannot connect to Internet...Please check your connection!";
        } else if (error instanceof ServerError) {
            message = "The server could not be found. Please try again after some time!!";
        } else if (error instanceof AuthFailureError) {
            message = "Cannot connect to Server...AuthFailureError!";
        } else if (error instanceof ParseError) {
            message = "Parsing error! Please try again after some time!!";
        } else if (error instanceof NoConnectionError) {
            message = "Cannot connect to Internet...Please check your connection!";
        } else if (error instanceof TimeoutError) {
            message = "Connection TimeOut! Please check your internet connection.";
        }else {message = "unknown error!";}

        Toast.makeText(mContext, "error "+message, Toast.LENGTH_LONG).show();

    }
}
