package utils;

public interface VolleyCallback {
    void onSuccess(String result);
}

